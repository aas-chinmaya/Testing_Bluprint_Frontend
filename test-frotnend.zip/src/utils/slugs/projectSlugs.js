export const projectSlugs = [
  "overview",
  "task",
  "bug",
  "document",
  "mom",
  "dashboard",
];
