
import AllIssuesListByEmployeeId from "@/modules/project-management/issues/components/AllIssuesListByEmployeeId";

export default function Page() {


  return (
    <AllIssuesListByEmployeeId/>
  );
}