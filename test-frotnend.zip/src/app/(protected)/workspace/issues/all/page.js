
import AllIssuesList from "@/modules/project-management/issues/components/AllIssuesList";

export default function Page() {


  return (
    <AllIssuesList/>
  );
}