'use client';


import AllTask from '@/modules/project-management/task/components/AllTask';





export default function AllTaskListByRole() {


  return (
    <div className="">
      <AllTask  />
 
    </div>
  );
}