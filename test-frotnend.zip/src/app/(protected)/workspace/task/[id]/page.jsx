import ViewTask from "@/modules/project-management/task/components/ViewTask";

export default function Page() {
  return (
    <>
 
        <ViewTask/>
     
    </>
  );
}


