'use client';

import AllTeamList from "@/modules/project-management/team/components/AllTeamList";



export default function AllTeamByRole() {



  return (
    <div className="">
      
       <AllTeamList   />
     



    
    </div>
  );
}