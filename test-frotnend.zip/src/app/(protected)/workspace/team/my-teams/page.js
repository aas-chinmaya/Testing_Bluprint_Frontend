'use client';


import TeamListByEmployeeId from '@/modules/project-management/team/components/TeamListByEmployeeId';


export default function AllTeamByRole() {



  return (
    <div className="">
      
        <TeamListByEmployeeId  />
      



    
    </div>
  );
}