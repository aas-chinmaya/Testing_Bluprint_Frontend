"use client";
import AllClientList from "@/modules/client-management/components/AllClientList";

export default function Page() {
  return (
    <>
     
        <AllClientList />
     
    </>
  );
}
