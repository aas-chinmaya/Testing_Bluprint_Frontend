'use client';

import AddClient from '@/modules/client-management/components/ClientOnboarding';
import React from 'react';

export default function ClientOnboarding() {
  return (
       <>
      
          
          <AddClient />
        
        </>
     
      
  );
}