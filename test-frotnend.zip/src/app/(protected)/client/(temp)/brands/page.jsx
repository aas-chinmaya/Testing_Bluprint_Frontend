export default function BrandPage() {
  return (
    <div className="flex h-screen items-center justify-center">
      <h1 className="text-2xl font-semibold">
        This is the Brand  Page
      </h1>
    </div>
  )
}
