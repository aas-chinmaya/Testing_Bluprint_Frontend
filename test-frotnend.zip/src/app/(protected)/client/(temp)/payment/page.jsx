export default function PaymentPage() {
  return (
    <div className="flex h-screen items-center justify-center">
      <h1 className="text-2xl font-semibold">
        This is the Payment Page
      </h1>
    </div>
  )
}
