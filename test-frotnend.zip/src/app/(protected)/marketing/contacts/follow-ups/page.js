'use client';





export default function Contact() {


  return (
    <div className="">
    

Follow ups
   
    </div>
  );
}