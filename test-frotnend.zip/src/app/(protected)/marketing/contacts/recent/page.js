'use client';

import RecentContactsList from "@/modules/marketing/components/RecentContactsList";





export default function Contact() {


  return (
    <div className="">
    


    <RecentContactsList/>
    </div>
  );
}