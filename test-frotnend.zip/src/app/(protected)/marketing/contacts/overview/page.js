'use client';

import MarketingOverview from "@/modules/marketing/components/OverviewMarketing";





export default function Overview() {


  return (
    <div className="">
    

<MarketingOverview/>
   
    </div>
  );
}