'use client';

import AllContacts from "@/modules/marketing/components/AllContacts";





export default function Contact() {


  return (
    <div className="">
    

<AllContacts/>
   
    </div>
  );
}