
import Industry from "@/modules/master/components/IndustryMaster";



export default function page() {
 

  return (
  
  
      <Industry/> 
   
  );
}
