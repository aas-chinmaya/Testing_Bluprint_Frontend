
import Service from "@/modules/master/components/ServiceMaster";



export default function page() {
 

  return (
  
      <Service/> 
  
  );
}
