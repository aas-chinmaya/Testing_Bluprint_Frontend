
import SlotMaster from "@/modules/master/components/SlotMaster";



export default function page() {
 

  return (

  
      <SlotMaster/> 

  );
}
