"use client";

import QuotationList from "@/modules/sales/components/QuotationList";



export default function page() {
 

  return (
    <>
  
      <QuotationList/> 
    </>
  );
}
