// app/page.js
'use client';

import ProjectList from '@/modules/project-management/project/components/ProjectList';

export default function Page() {

  


  return (
    <ProjectList
     
      
    />
  );
}