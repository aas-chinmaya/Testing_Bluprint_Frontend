'use client';
import React from 'react';
import ProjectOnboardingForm from '@/modules/project-management/project/components/ProjectOnboarding';


export default function Page() {
  return (
    <>
   
        
<ProjectOnboardingForm />
      
    </>
  );
}
      
     
 
