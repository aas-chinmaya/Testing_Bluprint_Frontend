

// app/meeting/[Id]/page.js
"use client";

import CauseDashboard from "@/modules/escalation/components/causeDashboard";



export default function MeetingControllerPage() {
  
  return <CauseDashboard  />;
}






