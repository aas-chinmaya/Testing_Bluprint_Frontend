"use client";

import QuotationList from "@/modules/sales/components/quotationRequest";



export default function page() {
 

  return (
    <>
  
      <QuotationList/> 
    </>
  );
}
