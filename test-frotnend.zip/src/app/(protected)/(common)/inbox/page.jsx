'use client';

import Inbox from "@/modules/communication/components/inbox";



export default function AllTeamByRole() {


  return (
    <div className="">
     <Inbox  />



    
    </div>
  );
}