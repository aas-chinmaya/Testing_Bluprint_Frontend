// const path = require('path');
// const fs = require('fs');
// const ejs = require('ejs');
// const puppeteer = require('puppeteer');
// /**
//  * Generate Project MOM PDF
//  * @param {Object} momData - Project MoM data
//  * @returns {Buffer} PDF Buffer
//  */
// const generateProjectMomPDF = async (momData) => {
//   try {
//     const templatePath = path.join(__dirname, './momTemplate.ejs');

//     // Format current time
//     const currentTime = new Date().toLocaleTimeString('en-US', {
//       hour: '2-digit',
//       minute: '2-digit',
//       hour12: true
//     });

//     // Prepare signature image as base64
//     let signatureDataUrl = null;
//     if (momData.signature && typeof momData.signature === 'string') {
//       const signaturePath = path.resolve(process.cwd(), momData.signature);
//       console.log('Resolved Signature Path:', signaturePath);

//       if (fs.existsSync(signaturePath)) {
//         const buffer = fs.readFileSync(signaturePath);
//         const ext = path.extname(signaturePath).toLowerCase();
//         const mimeType =
//           ext === '.jpg' || ext === '.jpeg' ? 'image/jpeg' : 'image/png';
//         signatureDataUrl = `data:${mimeType};base64,${buffer.toString('base64')}`;
//       } else {
//         console.warn('Signature image NOT found at:', signaturePath);
//       }
//     }

//     // Prepare logo image as base64
//     const logoPath = path.join(__dirname, './logo.png');
//     let logoDataUrl = null;
//     if (fs.existsSync(logoPath)) {
//       const logoBuffer = fs.readFileSync(logoPath);
//       logoDataUrl = `data:image/png;base64,${logoBuffer.toString('base64')}`;
//     }

//     // Render HTML with EJS
//     const html = await ejs.renderFile(templatePath, {
//       momData,
//       currentTime,
//       signatureDataUrl,
//       logoDataUrl
//     });

//     // Puppeteer launch (Ubuntu 24.04 safe)
//     const browser = await puppeteer.launch({
//       headless: 'new', // use true if older puppeteer
//       args: [
//         '--no-sandbox',
//         '--disable-setuid-sandbox',
//         '--disable-dev-shm-usage',
//         '--disable-gpu',
//         '--no-zygote'
//       ]
//     });

//     const page = await browser.newPage();
//     await page.setContent(html, { waitUntil: 'networkidle0' });

//     // Generate PDF
//     const pdfBuffer = await page.pdf({
//       format: 'A4',
//       printBackground: true,
//       margin: { top: '40px', bottom: '40px', left: '40px', right: '40px' }
//     });

//     await browser.close();
//     return pdfBuffer;
//   } catch (err) {
//     console.error('PDF Generation Error:', err);
//     throw new Error('Failed to generate MoM PDF: ' + err.message);
//   }
// };

// module.exports = generateProjectMomPDF;
const path = require('path');
const fs = require('fs');
const ejs = require('ejs');
const puppeteer = require('puppeteer');

/**
 * Generate Project MOM PDF
 * @param {Object} momData - Project MoM data
 * @returns {Buffer} PDF Buffer
 */
const generateProjectMomPDF = async (momData) => {
  try {
    const templatePath = path.join(__dirname, './momTemplate.ejs');

    // Format current time
    const currentTime = new Date().toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });

    // ✅ Normalize attendees before passing to EJS
    let attendees = [];
    if (Array.isArray(momData.attendees)) {
      attendees = momData.attendees;
    } else if (typeof momData.attendees === 'string') {
      attendees = momData.attendees.split(',').map(a => a.trim());
    }

    // Prepare signature image as base64
    let signatureDataUrl = null;
    if (momData.signature && typeof momData.signature === 'string') {
      const signaturePath = path.resolve(process.cwd(), momData.signature);
      console.log('Resolved Signature Path:', signaturePath);

      if (fs.existsSync(signaturePath)) {
        const buffer = fs.readFileSync(signaturePath);
        const ext = path.extname(signaturePath).toLowerCase();
        const mimeType =
          ext === '.jpg' || ext === '.jpeg' ? 'image/jpeg' : 'image/png';
        signatureDataUrl = `data:${mimeType};base64,${buffer.toString('base64')}`;
      } else {
        console.warn('Signature image NOT found at:', signaturePath);
      }
    }

    // Prepare logo image as base64
    const logoPath = path.join(__dirname, './logo.png');
    let logoDataUrl = null;
    if (fs.existsSync(logoPath)) {
      const logoBuffer = fs.readFileSync(logoPath);
      logoDataUrl = `data:image/png;base64,${logoBuffer.toString('base64')}`;
    }

    // Render HTML with EJS
    const html = await ejs.renderFile(templatePath, {
      momData,
      currentTime,
      attendees,          // ✅ Pass normalized attendees separately
      signatureDataUrl,
      logoDataUrl
    });

    // Puppeteer launch (Ubuntu 24.04 safe)
    const browser = await puppeteer.launch({
      headless: 'new', // use true if older puppeteer
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--no-zygote'
      ]
    });

    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });

    // Generate PDF
    const pdfBuffer = await page.pdf({
      format: 'A4',
      printBackground: true,
      margin: { top: '40px', bottom: '40px', left: '40px', right: '40px' }
    });

    await browser.close();
    return pdfBuffer;
  } catch (err) {
    console.error('PDF Generation Error:', err);
    throw new Error('Failed to generate MoM PDF: ' + err.message);
  }
};

module.exports = generateProjectMomPDF;
