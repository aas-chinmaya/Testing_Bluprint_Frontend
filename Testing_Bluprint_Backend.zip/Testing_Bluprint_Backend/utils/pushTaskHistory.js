const Task = require('../Model/TaskModel/Task');

const pushTaskHistory = async (taskId, updateData) => {
  const task = await Task.findOne({ task_id: taskId });
  if (!task) return;

  // Don't log if reviewStatus is 'Resolved'
  if (task.reviewStatus === 'Resolved') return;

  task.taskHistory.push({
    ...updateData,
    timestamp: new Date()
  });

  await task.save();
};

module.exports = pushTaskHistory;