const express = require('express');
const router = express.Router();
const {createQuotation,getQuotationByNumber,getClientStatusByQuotationId, getAllQuotations,getQuotationPDF,downloadQuotationPDF,handleStatusAction,renderStatusPage} = require('../../Controller/QuotationController/QuotationController');

// POST /api/quotations
router.post('/create', createQuotation);
router.get('/pdfbyqoutationnumber/:quotationNumber',  getQuotationPDF);
router.get('/pdf/download/:quotationNumber', downloadQuotationPDF);
router.post('/status/:quotationNumber/update', handleStatusAction);
router.get('/status/:quotationNumber', renderStatusPage);
router.get('/getAllquotations', getAllQuotations);  
router.get('/client-status-by-quotation/:quotationId', getClientStatusByQuotationId);  
router.get('/qoutationbynumber/:quotationNumber', getQuotationByNumber);  

module.exports = router;