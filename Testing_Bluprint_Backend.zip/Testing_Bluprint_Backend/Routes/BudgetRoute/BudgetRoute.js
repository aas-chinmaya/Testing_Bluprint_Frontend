// const express = require('express');
// const router = express.Router();
// const budgetRequestController = require('../../Controller/ProjectController/BudgetController');

// // Create a budget request
// router.post('/create', budgetRequestController.createBudgetRequest);

// // Get all budget requests
// router.get('/getallbudget', budgetRequestController.getAllBudgetRequests);

// // Get a single budget request by ID
// router.get('/getbudget/:id', budgetRequestController.getBudgetRequestById);

// // Update a budget request
// router.put('/updatebudget/:id', budgetRequestController.updateBudgetRequest);

// // Soft delete a budget request
// router.delete('/deletebudget/:id', budgetRequestController.deleteBudgetRequest);

// // Update status of a budget request
// router.patch('/updatebudget/:id/status', budgetRequestController.updateBudgetRequestStatus);

// module.exports = router;


const express = require('express');
const router = express.Router();
const budgetRequestController = require('../../Controller/BudgetController/BudgetController');
 
// Create a budget request
router.post('/create', budgetRequestController.createBudgetRequest);
 
// Get all budget requests
router.get('/getallbudget', budgetRequestController.getAllBudgetRequests);
router.get(
  "/getallbudget/project/:projectId",
  budgetRequestController.getAllBudgetRequestsByProjectId
); 
// Get a single budget request by ID
router.get('/getbudget/:requestId', budgetRequestController.getBudgetRequestById);
 
// Update a budget request
router.put('/updatebudget/:requestId', budgetRequestController.updateBudgetRequest);
 
// Soft delete a budget request
router.delete('/deletebudget/:requestId', budgetRequestController.deleteBudgetRequest);
 
// Update status of a budget request
router.put('/updatebudget/:requestId/status', budgetRequestController.updateBudgetRequestStatus);
 








//Budget Account


module.exports = router;
 
 