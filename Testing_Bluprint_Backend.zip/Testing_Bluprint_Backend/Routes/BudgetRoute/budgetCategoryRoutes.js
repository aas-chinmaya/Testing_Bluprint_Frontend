const express = require("express");
const router = express.Router();
const {
  createCategory,
  getAllCategories,
  getCategoryById,
  updateCategory,
  deleteCategory,
  getCategoriesByAccountId,
} = require("../../Controller/BudgetController/budgetCategoryController")
// Create new category
router.post("/createcatgory", createCategory);

// Get all categories
router.get("/getallcategories", getAllCategories);

// Get single category by categoryId
router.get("/getcatgorybyid/:categoryId", getCategoryById);

// Update category by categoryId
router.put("/updatecatgory/:categoryId", updateCategory);

// Soft delete category by categoryId
router.delete("/deletecatgory/:categoryId", deleteCategory);

router.get("/getallcategories/:accountId", getCategoriesByAccountId);



module.exports = router;
