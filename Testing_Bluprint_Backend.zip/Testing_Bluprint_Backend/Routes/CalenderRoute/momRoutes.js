const express = require('express');
const multer = require('multer');
const path = require('path');
const {getMoMByMomId,getMOMsByProjectId, createProjectMOM,createMOM,getMOMByMeetingId, updateMOM,downloadMOM,getAllMOMs,getMOMById,viewMOM} = require('../../Controller/CalenderController/momController');
 
const router = express.Router();
const storage = multer.memoryStorage();
 
 
 
const upload = multer({ storage });
 
router.post('/createmom',  upload.single('signature'), createMOM);
router.get('/pdf/:momId', downloadMOM);
 
 
// Get all MOMs
router.get('/getallmoms', getAllMOMs);

//for view the mom
router.get('/view/:momId', viewMOM); // Preview
 
// Get MOM by momId
router.get('/getbyid/:momId', getMOMById);


 // Get MOM by meetingId
router.get('/byMeeting/:meetingId', getMOMByMeetingId);
// UPDATE MOM
router.put('/update', upload.single('signature'),updateMOM);

router.post('/projectmom', upload.single('signature'), createProjectMOM );

router.get('/getmombymomid/:momId', getMoMByMomId);

router.get('/project/:projectId', getMOMsByProjectId);


module.exports = router;
 