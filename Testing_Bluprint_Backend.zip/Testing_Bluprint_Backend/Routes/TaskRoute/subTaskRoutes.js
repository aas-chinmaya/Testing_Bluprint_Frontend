const express = require('express');
const router = express.Router();
const SubtaskController = require('../../Controller/TaskController/subTaskController');

// Create subtask
router.post('/createsubtask/:taskId', SubtaskController.createSubtask);
router.get('/getallsubtasks/:taskId', SubtaskController.getAllSubtasks);
router.get('/getsubtask/:taskId/:subtaskId', SubtaskController.getSubtaskById);
router.put('/updatesubtask/:taskId/:subtaskId', SubtaskController.editSubtask);
router.put('/updatesubtaskstatus/:taskId/:subtaskId', SubtaskController.updateSubtaskStatusById);
router.delete('/softdeletesubtask/:taskId/:subtaskId', SubtaskController.softDeleteSubtask);
router.get("/member/:assignedTo", SubtaskController.getTasksByAssignedTo);

module.exports = router;
