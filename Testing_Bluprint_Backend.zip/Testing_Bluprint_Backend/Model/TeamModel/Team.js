const mongoose = require('mongoose');
 
const teamSchema = new mongoose.Schema({
  teamId: { type: String, required: true },
  leadId: { type: String },
  projectId: { type: String, required: true },
  teamName: { type: String, required: true },
  projectName: { type: String,ref: 'Project', required: true },
  teamLeadId: { type: String, required: true },//it will be store the teamleadid
  teamLeadName: { type: String },
  teamMembers: [{
    memberId: { type: String, required: true },
    role: { type: String, required: true } ,// Each member has a role
    memberName: { type: String },
    email:{type: String},
 
  }],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  isDeleted: { type: Boolean, default: false }
 
});
 
module.exports = mongoose.model('Team', teamSchema);
 
 
 
 