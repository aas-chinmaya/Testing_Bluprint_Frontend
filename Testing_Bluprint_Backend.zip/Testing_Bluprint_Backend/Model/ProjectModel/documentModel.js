// models/Document.js
const mongoose = require('mongoose');

const documentSchema = new mongoose.Schema({
  documentId: { type: String, unique: true },
  projectId: { type: String, required: true },     // reference to projectId
  name: { type: String, required: true },          // user-given name
  description: { type: String },                   // optional description
  filePath: { type: String},      // stored file path
   isDeleted: { type: Boolean, default: false } ,
  uploadedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Document', documentSchema);
