
 const mongoose = require('mongoose');
const Team = require('../TeamModel/Team');
 
const projectSchema = new mongoose.Schema
({
  projectId :{ type: String, unique: true },
  clientId: { type: String },
  projectName: { type: String, required: true },
  category:{type: String,required: true},
  description: { type: String, required: true },
  startDate: { type: String },
  endDate: { type: String },
   expectedEndDate: { type: String },
  teamLeadId: { type:String,required: true },
  teamLeadName: { type: String },
  leadId : {type: String},
  team: { type: [String], default: [] },
  attachments:
  [
    {
      data: Buffer,
      contentType: String,
      filename: String
    }
  ],
  status:
  {
    type: String,
    enum: ['Planned', 'In Progress', 'Completed','Cancelled'],
    default: 'Planned'
  },
 
    //  Added review field
  review: {
    reviewer: { type: String }, // Team Lead's userId
    comment: { type: String, trim: true },
    rating: { type: Number, min: 1, max: 5 },
    reviewedAt: { type: Date, default: Date.now },
    recipientRole: { type: String, default: 'CPC' }
  },
   meetingIds: { type: [String], default: [] },
  isDeleted: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});
 
module.exports = mongoose.model('Project', projectSchema);
 