
const mongoose = require('mongoose');

const QuotationItemSchema = new mongoose.Schema({
  serviceName: String,
  basePrice: Number,
  sellPrice: Number,
});

const QuotationSchema = new mongoose.Schema({
  quotationNumber: String,
  date: Date,
  validTill: Date,
  
  clientDetails: {
    name: String,
    company: String,
    email: String,
    phone: String
  },
  
  serviceProviderDetails: {
    companyName: String,
    email: String,
    phone: String,
    website: String,
    gstin: String
  },
  
  projectTitle: String,
  scopeOfWork: String,
  deliverables: String,
  timeline: String,
  
  items: [QuotationItemSchema],
  taxPercent: Number,
  paymentTerms: String,
  termsAndConditions: String,

  preparedBy: {
    name: String,
    designation: String,
    email: String
  },
  status: {
    type: String,
    enum: ['pending', 'accepted', 'rejected', 'requested'],
    default: 'pending'
  },
Status: {
    type: String,
    enum: ['draft', 'final'],
    default: 'final'
  },

  createdBy: String,
  updatedBy: String,
  
  pdf: Buffer,
  pdfUrl: String,
  createdAt:{
    type:Date ,
    default:Date.now
  }
  
});

module.exports = mongoose.model('Quotation', QuotationSchema);