// models/Notification.js
const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
  recipientId: { type: String, required: true },
  message: { type: String, required: true },
  link: { type: String }, // Optional link to view project
  read: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
  isDeleted: { type: Boolean, default: false } 
});

module.exports = mongoose.model('Notification', notificationSchema);
