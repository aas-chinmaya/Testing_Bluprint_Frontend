const mongoose = require('mongoose');

const bugSchema = new mongoose.Schema({
  bug_id: { type: String, unique: true },

  // 🔹 Project Information
  projectId: { type: String, required: true },
  projectName: { type: String, required: true }, // ✅ fixed syntax (was type-String)

  // 🔹 Bug Details
  title: { type: String, required: true },
  description: { type: String },

  // 🔹 Assignment
  assignedTo: { type: String }, // could be user ID or name
  assignedToName: { type: String }, // optional — for readability (if you store full name)

  // 🔹 Tracking
  deadline: { type: Date },
  priority: {
    type: String,
    enum: ['Low', 'Medium', 'High', 'Critical'],
    default: 'Low'
  },
  status: {
    type: String,
    enum: ['Open', 'Resolved', 'Closed'],
    default: 'Open'
  },

  // 🔹 Resolution Info
  delayReason: { type: String },
  resolutionNote: { type: String },
  resolvedAt: { type: Date },

  // 🔹 File Upload (store path only)
  attachment: [{ type: String }],

  createdAt: { type: Date, default: Date.now },
});

// 🔹 Auto-generate Bug ID (e.g., BUG-001)
bugSchema.statics.createBugWithId = async function (bugData) {
  const lastBug = await this.findOne().sort({ createdAt: -1 });
  let nextId = 1;

  if (lastBug && lastBug.bug_id) {
    const lastIdNum = parseInt(lastBug.bug_id.split('-')[1]);
    nextId = lastIdNum + 1;
  }

  const bug_id = `BUG-${String(nextId).padStart(3, '0')}`;
  const newBug = new this({ bug_id, ...bugData });
  return newBug.save();
};

// 🔹 Middleware Validation
bugSchema.pre('save', function (next) {
  if (this.status === 'Resolved' && !this.resolutionNote) {
    return next(new Error('Resolution note is required when marking bug as Resolved'));
  }
  next();
});

module.exports = mongoose.model('Bugs', bugSchema);


