
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
module.exports = (connection) => {
  const EmployeeSchema = new mongoose.Schema({}, { strict: false });
  const UserSchema = new mongoose.Schema({}, { strict: false });
  const DepartmentSchema = new mongoose.Schema({}, { strict: false });
   
 UserSchema.pre('save', async function (next) {
    if(!this.isModified('password')) return next();
    this.password = await bcrypt.hash(this.password, 10);
    next();
   
});
 
 
 
UserSchema.methods.comparePassword = async function (password) {
  return bcrypt.compare(password, this.password);
};
 
UserSchema.methods.compareLoginOTP = async function (otp) {
  return bcrypt.compare(otp, this.loginOTP);
};
 
 
  const Employee = connection.model("Employee", EmployeeSchema, "employees");
  const User = connection.model("User", UserSchema, "users");
  const Department = connection.model("Department", DepartmentSchema, "departments");
 
  return { Employee, User ,Department};
};