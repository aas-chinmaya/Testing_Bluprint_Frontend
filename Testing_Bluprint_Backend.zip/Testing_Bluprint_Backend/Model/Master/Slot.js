const mongoose = require('mongoose');

const slotMasterSchema = new mongoose.Schema({
  slotNo: { type: Number, required: true, unique: true },
  startTime: { type: String, required: true }, // Format: 'HH:mm'
  endTime: { type: String, required: true },   // Format: 'HH:mm'
  shift: { type: String, required: true },     // Example: 'Morning'
}, { timestamps: true });

module.exports = mongoose.model('SlotMaster', slotMasterSchema);
