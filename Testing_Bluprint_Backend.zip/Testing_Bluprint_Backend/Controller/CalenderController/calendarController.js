const {google,oAuth2Client} = require('../../Config/google');
const Project=require('../../Model/ProjectModel/projectModel')

const UserToken=require("../../Model/CalenderModel/userTokenModel");
const Contact=require("../../Model/ContactModel/Contact")
const SCOPES = [
  'https://www.googleapis.com/auth/calendar',
  'https://www.googleapis.com/auth/userinfo.email'
];


const REDIRECT_URI ="http://localhost:8080/oauth2callback";
exports.getAuthUrl = (req, res) => {
  try {
    const authUrl = oAuth2Client.generateAuthUrl({
      access_type: 'offline',
      prompt: 'consent',
      scope: SCOPES,
      redirect_uri: REDIRECT_URI,
    });
    res.status(200).json({ url: authUrl });
  } catch (err) {
    console.error('Error generating auth URL:', err);
    res.status(500).json({ message: 'Failed to generate auth URL', error: err.message });
  }
};

exports.oauthCallback = async (req, res) => {
  const code = req.query.code;
  console.log('Received authorization code:', code);

  if (!code) {
    return res.status(400).send(' Missing authorization code.');
  }

  try {
    const { tokens } = await oAuth2Client.getToken(code);
    console.log('Received tokens:', tokens);
    oAuth2Client.setCredentials(tokens);

    const oauth2 = google.oauth2({ auth: oAuth2Client, version: 'v2' });
    const { data } = await oauth2.userinfo.get();

    if (!data.email) {
      return res.status(400).send(' Email not found in Google response.');
    }

    await UserToken.findOneAndUpdate(
      { email: data.email },
      { tokens },
      { upsert: true, new: true }
    );

    return res.send(' Google account linked! You can now create meetings.');
  } catch (err) {
    console.error('OAuth Error:', err?.response?.data || err.message);
    if (err.response?.data?.error === 'invalid_grant') {
      const authUrl = oAuth2Client.generateAuthUrl({
        access_type: 'offline',
        prompt: 'consent',
        scope: SCOPES,
      });
      return res.status(400).json({
        message: ' Google account linked! You can now create meetings.',
        // authUrl,
      });
    }
    return res.status(500).send(' OAuth callback failed: ' + err.message);
  }
};


function padTime(timeStr) {
  const [hh, mm] = timeStr.split(":");
  return `${hh.padStart(2, "0")}:${mm.padStart(2, "0")}`;
}

exports.createMeeting = async (req, res) => {

  const { email, summary, description, attendees, date, selectedSlot } = req.body;
 
  try {

    // Step 1: Validate user token

    const user = await UserToken.findOne({ email });

    if (!user) {

      const authUrl = oAuth2Client.generateAuthUrl({

        access_type: 'offline',

        prompt: 'consent',

        scope: SCOPES,

      });

      return res.status(401).json({ message: 'User not authorized', url: authUrl });

    }
 
    oAuth2Client.setCredentials(user.tokens);
 
    // Step 2: Build startTime and endTime as ISO strings

    const { startTime, endTime } = selectedSlot;

    const timeZone = 'Asia/Kolkata'; // Adjust if needed
 
    const startDateTime = new Date(`${date}T${startTime}:00+05:30`).toISOString();

    const endDateTime = new Date(`${date}T${endTime}:00+05:30`).toISOString();
 
    // Step 3: Prepare Google Calendar Event

    const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });
 
    const event = {

      summary,

      description,

      start: {

        dateTime: startDateTime,

        timeZone,

      },

      end: {

        dateTime: endDateTime,

        timeZone,

      },

      attendees,

      conferenceData: {

        createRequest: {

          requestId: `meet-${Date.now()}`,

          conferenceSolutionKey: { type: 'hangoutsMeet' },

        },

      },

    };
 
    // Step 4: Insert event with conference details

    const response = await calendar.events.insert({

      calendarId: 'primary',

      resource: event,

      conferenceDataVersion: 1,

    });
 
    res.status(200).json({

      message: 'Meeting created successfully',

      link: response.data.hangoutLink,

      eventId: response.data.id,

      createdBy: email,

      event: response.data,

    });

  } catch (err) {

    console.error('Meeting Creation Error:', err);

    res.status(500).json({ message: 'Failed to create meeting', error: err.message });

  }

};

 


exports.getUpcomingMeetings = async (req, res) => {
  const { email } = req.params;

  try {
    const user = await UserToken.findOne({ email });

    if (!user) {
      const authUrl = oAuth2Client.generateAuthUrl({
        access_type: 'offline',
        prompt: 'consent',
        scope: SCOPES,
      });
      return res.status(400).json({ message: 'User not authorized', url: authUrl });
    }

    oAuth2Client.setCredentials(user.tokens);

    const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });

    const response = await calendar.events.list({
      calendarId: 'primary',
      maxResults: 100, // increase if needed
      singleEvents: true,
      orderBy: 'startTime',
    });

    const events = response.data.items || [];

    const formattedMeetings = events.map(event => ({
      hostEmail: user.email,
      eventId: event.id,
      summary: event.summary,
      description: event.description,
      start: event.start,
      end: event.end,
      attendees: event.attendees || [],
      hangoutLink: event.hangoutLink || null,
      htmlLink: event.htmlLink,
      conferenceData: event.conferenceData || null,
    }));

    res.status(200).json({
      message: `Fetched all meetings (past and upcoming) for ${email}`,
      totalMeetings: formattedMeetings.length,
      meetings: formattedMeetings,
    });
  } catch (err) {
    console.error(` Error fetching meetings for ${email}:`, err);
    res.status(500).json({ message: 'Failed to fetch meetings', error: err.message });
  }
};




exports.updateMeeting = async (req, res) => {
  const { email, eventId, summary, description, startTime, endTime, attendees } = req.body;

  try {
    const user = await UserToken.findOne({ email });
    console.log(user)
    
    if (!user) {
      const authUrl = oAuth2Client.generateAuthUrl({
        access_type: 'offline',
        prompt: 'consent',
        scope: SCOPES,
      });
      return res.status(400).json({ message: 'User not authorized', url: authUrl });
    }
    console.log(user)

    oAuth2Client.setCredentials(user.tokens);

    const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });

    const existingEvent = await calendar.events.get({
      calendarId: 'primary',
      eventId: eventId,
    });

    const updatedEvent = {
      ...existingEvent.data,
      summary: summary || existingEvent.data.summary,
      description: description || existingEvent.data.description,
      start: startTime ? { dateTime: startTime } : existingEvent.data.start,
      end: endTime ? { dateTime: endTime } : existingEvent.data.end,
      attendees: attendees || existingEvent.data.attendees,
    };

    const response = await calendar.events.update({
      calendarId: 'primary',
      eventId: eventId,
      resource: updatedEvent,
      conferenceDataVersion: 1,
    });

    res.status(200).json({
      message: 'Meeting updated successfully',
      updatedEvent: response.data,
    });
  } catch (err) {
    console.error('Update Error:', err);
    res.status(500).json({ message: 'Failed to update meeting', error: err.message });
  }
};




exports.updateMeeting = async (req, res) => {
  const { email, eventId, summary, description, attendees, date, selectedSlot } = req.body.meetingData;
  //console.log("Payload:", email, eventId, summary, description, date, selectedSlot, attendees);
 console.log("Payload:",email);
 
  try {
    const user = await UserToken.findOne({ email });
    if (!user) {
      const authUrl = oAuth2Client.generateAuthUrl({
        access_type: 'offline',
        prompt: 'consent',
        scope: SCOPES,
      });
      return res.status(200).json({ message: 'User not authorized', url: authUrl });
    }
 
    oAuth2Client.setCredentials(user.tokens);
    const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });
 
    // Fetch the current event
    const existingEvent = await calendar.events.get({
      calendarId: 'primary',
      eventId,
    });
 
    // Format times
    const startTimeFormatted = padTime(selectedSlot.startTime); // e.g., "05:00"
    const endTimeFormatted = padTime(selectedSlot.endTime);     // e.g., "05:30"
 
    // Combine date and time into ISO format
    const startDateTime = new Date(`${date}T${startTimeFormatted}:00+05:30`);
    const endDateTime = new Date(`${date}T${endTimeFormatted}:00+05:30`);
 
    // Construct the updated event
    const updatedEvent = {
      summary: summary || existingEvent.data.summary,
      description: description || existingEvent.data.description,
      start: {
        dateTime: startDateTime.toISOString(),
        timeZone: 'Asia/Kolkata',
      },
      end: {
        dateTime: endDateTime.toISOString(),
        timeZone: 'Asia/Kolkata',
      },
      attendees: attendees || existingEvent.data.attendees,
      conferenceData: existingEvent.data.conferenceData || {
        createRequest: {
          requestId: `meet-update-${Date.now()}`,
          conferenceSolutionKey: { type: 'hangoutsMeet' },
        },
      },
    };
 
    const response = await calendar.events.update({
      calendarId: 'primary',
      eventId,
      resource: updatedEvent,
      conferenceDataVersion: 1,
    });
 
    res.status(200).json({
      message: 'Meeting updated successfully',
      host: email,
      updatedEvent: {
        id: response.data.id,
        summary: response.data.summary,
        description: response.data.description,
        start: response.data.start,
        end: response.data.end,
        attendees: response.data.attendees || [],
        hangoutLink: response.data.hangoutLink,
        htmlLink: response.data.htmlLink,
      },
    });
  } catch (err) {
    console.error('Meeting Update Error:', err);
    res.status(500).json({ message: 'Meeting update failed', error: err.message });
  }
};
 
 
exports.deleteMeeting = async (req, res) => {
  const { email, eventId } = req.params;

  try {
    const user = await UserToken.findOne({ email });
    if (!user) {
      const authUrl = oAuth2Client.generateAuthUrl({
        access_type: 'offline',
        prompt: 'consent',
        scope: SCOPES,
      });
      return res.status(400).json({ message: 'User not authorized', url: authUrl });
    }

    oAuth2Client.setCredentials(user.tokens);

    const oauth2 = google.oauth2({ version: 'v2', auth: oAuth2Client });
    const userInfo = await oauth2.userinfo.get();
    if (userInfo.data.email !== email) {
      return res.status(403).json({ message: 'Token does not match user email' });
    }

    const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });

    await calendar.events.get({
      calendarId: 'primary',
      eventId: eventId,
    });

    await calendar.events.delete({
      calendarId: 'primary',
      eventId: eventId,
    });

    return res.status(200).json({
      message: 'Meeting deleted successfully',
      eventId,
      deletedBy: email,
    });
  } catch (err) {
    console.error('Delete Error:', err.message);
    const status = err.code === 404 ? 404 : 500;
    res.status(status).json({
      message: err.code === 404 ? 'Event not found or unauthorized' : 'Failed to delete meeting',
      error: err.message,
      eventId,
    });
  }
};





exports.getMeetingsByContactId = async (req, res) => {
  const { contactId } = req.params;
  console
 
  try {
    // Step 1: Fetch the contact using contactId
    const contact = await Contact.findOne({ contactId, isDeleted: false });
      console.log("contact",contact)
    if (!contact) {
      return res.status(404).json({ message: ' Contact not found' });
    }
   
    const email = contact.email;
    console.log(` Found contact with email: ${email}`);
 
    // Step 2: Find the Google token for that email
    const user = await UserToken.findOne({ email });
    if (!user) {
      const authUrl = oAuth2Client.generateAuthUrl({
        access_type: 'offline',
        prompt: 'consent',
        scope: SCOPES,
      });
      return res.status(401).json({
        message: ' This contact has not authorized access to Google Calendar.',
        authUrl,
      });
    }
 
    // Step 3: Set credentials and fetch meetings
    oAuth2Client.setCredentials(user.tokens);
 
    const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });
 
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
 
    const response = await calendar.events.list({
      calendarId: 'primary',
      timeMin: startOfDay.toISOString(),
      maxResults: 50,
      singleEvents: true,
      orderBy: 'startTime',
    });
 
    const events = response.data.items || [];
 
    res.status(200).json({
      message: 'Upcoming meetings fetched successfully',
      contactId,
      email,
      count: events.length,
      events: events.map(event => ({
        id: event.id,
        summary: event.summary,
        description: event.description,
        start: event.start,
        end: event.end,
        attendees: event.attendees || [],
        hangoutLink: event.hangoutLink || null,
        htmlLink: event.htmlLink,
        conferenceData: event.conferenceData || null,
      })),
    });
  } catch (err) {
    console.error(' Error fetching meetings by contactId:', err);
    res.status(500).json({
      message: ' Failed to fetch meetings for contact',
      error: err.message,
    });
  }
};




exports.getAllMeetings = async (req, res) => {
  try {
    const users = await UserToken.find();

    if (!users || users.length === 0) {
      return res.status(404).json({ message: 'No authorized users found' });
    }

    const allMeetings = [];

    for (const user of users) {
      try {
        oAuth2Client.setCredentials(user.tokens);

        const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });

        const response = await calendar.events.list({
          calendarId: 'primary',
          maxResults: 100,
          singleEvents: true,
          orderBy: 'startTime',
        });

        const events = response.data.items || [];

        events.forEach(event => {
          allMeetings.push({
            hostEmail: user.email,
            eventId: event.id,
            summary: event.summary,
            description: event.description,
            start: event.start,
            end: event.end,
            attendees: event.attendees || [],
            hangoutLink: event.hangoutLink || null,
            htmlLink: event.htmlLink,
            conferenceData: event.conferenceData || null,
          });
        });
      } catch (innerErr) {
        console.warn(` Failed to fetch meetings for ${user.email}:`, innerErr.message);
      }
    }

    res.status(200).json({
      message: 'Fetched all meetings (past and upcoming) for all users',
      totalMeetings: allMeetings.length,
      meetings: allMeetings,
    });
  } catch (err) {
    console.error('Error fetching all meetings:', err);
    res.status(500).json({ message: 'Failed to fetch all meetings', error: err.message });
  }
};





exports.createTeamMeeting = async (req, res) => {

  const { email, summary, description, attendees, date, selectedSlot, projectId } = req.body;
 
  try {

    // Step 1: Validate user token

    const user = await UserToken.findOne({ email });

    if (!user) {

      const authUrl = oAuth2Client.generateAuthUrl({

        access_type: 'offline',

        prompt: 'consent',

        scope: SCOPES,

      });

      return res.status(401).json({ message: 'User not authorized', url: authUrl });

    }
 
    oAuth2Client.setCredentials(user.tokens);
 
    // Step 2: Build startTime and endTime as ISO strings

    const { startTime, endTime } = selectedSlot;

    const timeZone = 'Asia/Kolkata';
 
    const startDateTime = new Date(`${date}T${startTime}:00+05:30`).toISOString();

    const endDateTime = new Date(`${date}T${endTime}:00+05:30`).toISOString();
 
    // Step 3: Prepare Google Calendar Event

    const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });
 
    const event = {

      summary,

      description,

      start: { dateTime: startDateTime, timeZone },

      end: { dateTime: endDateTime, timeZone },

      attendees,

      conferenceData: {

        createRequest: {

          requestId: `meet-${Date.now()}`,

          conferenceSolutionKey: { type: 'hangoutsMeet' },

        },

      },

    };
 
    // Step 4: Insert event with conference details

    const response = await calendar.events.insert({

      calendarId: 'primary',

      resource: event,

      conferenceDataVersion: 1,

    });
 
    const meetingId = response.data.id;
 
    // Step 5: Update the Project with this meetingId

    if (projectId) {

      await Project.findOneAndUpdate(

        { projectId },

        { $push: { meetingIds: meetingId } },

        { new: true }

      );

    }
 
    // Step 6: Return success response

    res.status(200).json({

      message: 'Meeting created successfully',

      link: response.data.hangoutLink,

      eventId: meetingId,

      createdBy: email,

      event: response.data,

    });
 
  } catch (err) {

    console.error('Meeting Creation Error:', err);

    res.status(500).json({ message: 'Failed to create meeting', error: err.message });

  }

};
 




exports.getMeetingsByProjectId = async (req, res) => {
  const { projectId } = req.params;
 
  try {
    // Step 1: Find project
    const project = await Project.findOne({ projectId, isDeleted: false });
 
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }
 
    const meetingIds = project.meetingIds || [];
 
    if (meetingIds.length === 0) {
      return res.status(200).json({
        message: 'No meetings scheduled yet for this project',
        meetings: [],
      });
    }
 
    // Step 2: Use OAuth client to call Google Calendar
    const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });
 
    // Step 3: Fetch all meeting details
    const meetings = await Promise.all(
      meetingIds.map(async (eventId) => {
        try {
          const response = await calendar.events.get({
            calendarId: 'primary',
            eventId,
          });
 
          const event = response.data;
 
          return {
            eventId: event.id,
            summary: event.summary,
            description: event.description || '',
            start: event.start?.dateTime || event.start?.date,
            end: event.end?.dateTime || event.end?.date,
            location: event.location || 'Not specified',
            status: event.status,
            htmlLink: event.htmlLink,
            organizer: event.organizer?.email || 'Not available',
            attendees: event.attendees?.map((a) => ({
              email: a.email,
              responseStatus: a.responseStatus,
            })) || [],
            hangoutLink: event.hangoutLink || null,
            created: event.created,
            updated: event.updated,
          };
        } catch (err) {
          console.warn(`Could not fetch event ${eventId}:`, err.message);
          return null;
        }
      })
    );
 
    const filteredMeetings = meetings.filter(Boolean);
 
    return res.status(200).json({
      message: 'Meetings fetched successfully',
      count: filteredMeetings.length,
      meetings: filteredMeetings,
    });
  } catch (error) {
    console.error('Error fetching meetings:', error);
    return res.status(500).json({
      message: 'Failed to fetch meetings',
      error: error.message,
    });
  }
};