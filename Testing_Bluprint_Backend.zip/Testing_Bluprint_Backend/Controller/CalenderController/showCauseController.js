// Controller/CalenderController/showCauseController.js
const ShowCause = require('../../Model/CalenderModel/ShowCause');
const Mom = require('../../Model/CalenderModel/momModel');

exports.submitShowCause = async (req, res) => {

  try {

    const { meetingId, reason, submittedBy } = req.body;
 
    if (!meetingId || !reason || !submittedBy) {

      return res.status(400).json({ message: ' meetingId, reason, and submittedBy are required.' });

    }
 
    const momExists = await Mom.findOne({ meetingId });

    if (momExists) {

      return res.status(400).json({ message: ' MOM already submitted. Show cause not required.' });

    }
 
    const existing = await ShowCause.findOne({ meetingId });

    if (existing) {

      return res.status(400).json({ message: ' Show cause already submitted for this meeting.' });

    }
 
    // Generate showCauseId like AAS-IT-SC-YYYY-MM-DD-HHMMSS

    const now = new Date();

    const formattedDate = now.toISOString().split('T')[0]; // YYYY-MM-DD

    const formattedTime = now.toTimeString().split(' ')[0].replace(/:/g, ''); // HHMMSS

    const showCauseId = `AAS-IT-SC-${formattedDate}-${formattedTime}`;
 
    const showCause = await ShowCause.create({

      showCauseId,

      meetingId,

      reason,

      submittedBy

    });
 
    return res.status(201).json({

      message: 'Show cause submitted successfully.',

      data: showCause

    });
 
  } catch (err) {

    console.error(' Error submitting show cause:', err);

    res.status(500).json({ message: 'Failed to submit show cause', error: err.message });

  }

};

 exports.updateShowCauseStatus = async (req, res) => {
  try {
    const { showCauseId } = req.params;
    const { status } = req.body;
 
    if (![ 'Approved', 'Rejected'].includes(status)) {
      return res.status(400).json({ message: ' Invalid status. Must be Pending, Accepted, or Rejected.' });
    }
 
    const updated = await ShowCause.findOneAndUpdate(
      { showCauseId },
      { status },
      { new: true }
    );
 
    if (!updated) {
      return res.status(404).json({ message: ' Show cause not found for the given showCauseId.' });
    }
 
    return res.status(200).json({
      message: `Show cause status updated to "${status}" successfully.`,
      data: updated
    });
 
  } catch (error) {
    console.error(' Error updating show cause status:', error);
    res.status(500).json({ message: 'Failed to update show cause status', error: error.message });
  }
};
 

exports.getShowCauseByMeetingId = async (req, res) => {
  try {
    const { meetingId } = req.params;

    const record = await ShowCause.findOne({ meetingId });

    if (!record) {
      return res.status(404).json({ message: ' Show cause not found for this meeting.' });
    }

    res.status(200).json({ message: ' Show cause retrieved.', data: record });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch show cause', error: err.message });
  }
};

exports.getAllShowCauses = async (req, res) => {
  try {
    const records = await ShowCause.find().sort({ submittedAt: -1 });
    res.status(200).json({ message: ' All show causes fetched.', count: records.length, data: records });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch show causes', error: err.message });
  }
};
