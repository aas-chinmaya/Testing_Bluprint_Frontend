const ManpowerMaster = require("../../Model/BudgetModel/ManpowerMaster");

// =====================================
// Create Manpower Master (auto manpowerId)
// =====================================
exports.createManpower = async (req, res) => {
  try {
    // Use static method from model to auto-generate manpowerId
    const manpower = await ManpowerMaster.createManpowerWithId(req.body);

    res.status(201).json({
      success: true,
      message: "Manpower record created successfully",
      data: manpower,
    });
  } catch (err) {
    res.status(400).json({
      success: false,
      message: err.message,
    });
  }
};

// =====================================
// Get All Manpower Records (with filters)
// =====================================
exports.getAllManpower = async (req, res) => {
  try {
    const { department, role, level, primarySkill, isActive } = req.query;
    const filter = { isDeleted: false };

    if (department) filter.department = department;
    if (role) filter.role = role;
    if (level) filter.level = level;
    if (primarySkill)
      filter.primarySkill = { $regex: primarySkill, $options: "i" };
    if (isActive !== undefined) filter.isActive = isActive === "true";

    const records = await ManpowerMaster.find(filter).sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: records.length,
      data: records,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

// =====================================
// Get Single Manpower Record by manpowerId
// =====================================
exports.getManpowerById = async (req, res) => {
  try {
    const manpower = await ManpowerMaster.findOne({
      manpowerId: req.params.manpowerId,
      isDeleted: false,
    });

    if (!manpower)
      return res.status(404).json({
        success: false,
        message: "Manpower record not found",
      });

    res.status(200).json({
      success: true,
      data: manpower,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

// =====================================
// Update Manpower Record by manpowerId
// =====================================
exports.updateManpower = async (req, res) => {
  try {
    const manpower = await ManpowerMaster.findOneAndUpdate(
      { manpowerId: req.params.manpowerId, isDeleted: false },
      { ...req.body, editedBy: req.body.editedBy || "System" },
      { new: true, runValidators: true }
    );

    if (!manpower)
      return res.status(404).json({
        success: false,
        message: "Manpower record not found",
      });

    res.status(200).json({
      success: true,
      message: "Manpower record updated successfully",
      data: manpower,
    });
  } catch (err) {
    res.status(400).json({
      success: false,
      message: err.message,
    });
  }
};

// =====================================
// Soft Delete Manpower Record by manpowerId
// =====================================
exports.deleteManpower = async (req, res) => {
  try {
    const manpower = await ManpowerMaster.findOneAndUpdate(
      { manpowerId: req.params.manpowerId, isDeleted: false },
      { isDeleted: true, isActive: false },
      { new: true }
    );

    if (!manpower)
      return res.status(404).json({
        success: false,
        message: "Manpower record not found",
      });

    res.status(200).json({
      success: true,
      message: "Manpower record deleted successfully",
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};
