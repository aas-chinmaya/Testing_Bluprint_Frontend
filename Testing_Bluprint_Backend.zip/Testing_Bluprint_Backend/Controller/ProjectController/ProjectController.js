const Project = require('../../Model/ProjectModel/projectModel');
 
const Team=require('../../Model/TeamModel/Team');
const Task=require('../../Model/TaskModel/Task');
const Notification=require('../../Model/NotificationModel/notificationModel');
const ProjectMom=require('../../Model/CalenderModel/ProjectMomModel');
const Bug=require('../../Model/BugModel/Bug');
const Mom = require('../../Model/CalenderModel/ProjectMomModel');
const Document=require("../../Model/ProjectModel/documentModel");


 
const createProject = async (req, res) => {
  try {
    const {
      projectName,
      description,
      teamLeadId,
      category,
      startDate,
      endDate,
      expectedEndDate, // added
      teamLeadName,
      team,
      clientId
    } = req.body;
 
    // Validate required fields
    if (!projectName || !description || !startDate  || !teamLeadId) {
      return res.status(400).json({
        success: false,
        message: "Project name, description, dates, and teamLeadId are required."
      });
    }
 
    // Handle file uploads
    let attachments = [];
    if (req.files && req.files.length > 0) {
      attachments = req.files.map(file => ({
        filename: file.originalname,
        contentType: file.mimetype,
        data: file.buffer
      }));
    }
 
    // Step 1: Get prefix from project name
    const prefix = projectName.substring(0, 3).toUpperCase();
 
    // Step 2: Get highest global project number
    const lastProject = await Project.findOne({
      projectId: { $regex: /^AAS-IT-[A-Z]{3}-\d{3}$/ }
    }).sort({ createdAt: -1 });
 
    let nextNumber = 1;
    if (lastProject?.projectId) {
      const number = parseInt(lastProject.projectId.split('-').pop());
      nextNumber = number + 1;
    }
 
    const formattedNumber = String(nextNumber).padStart(3, '0');
    const projectId = `AAS-IT-${prefix}-${formattedNumber}`;
 
    // Step 3: Generate leadId
    const yearSuffix = new Date().getFullYear().toString().slice(-2);
    const leadIdPrefix = `AAS-P-${formattedNumber}-${yearSuffix}`;
    const leadIdRegex = new RegExp(`^${leadIdPrefix}-\\d{3}$`);
 
    const existingLeadCount = await Project.countDocuments({
      leadId: { $regex: leadIdRegex }
    });
 
    const leadCounter = String(existingLeadCount + 1).padStart(3, '0');
    const leadId = `${leadIdPrefix}-${leadCounter}`;
 
    // Step 4: Create and save project
    const newProject = new Project({
      projectId,
      projectName,
      description,
      category,
      startDate,
      endDate,
      expectedEndDate: expectedEndDate || null, // added
      teamLeadId,
      teamLeadName,
      team: typeof team === 'string' ? JSON.parse(team) : team || [],
      attachments,
      leadId,
      clientId: clientId || null,
      meetingIds: [] // Initialized as empty array
    });
 
    await newProject.save();
 
    // Step 5: Notify team lead
    const notification = new Notification({
      recipientId: teamLeadId,
      message: `You have been assigned as the Team Lead for project "${projectName}".`,
      link: `/projects/${newProject._id}`
    });
 
    await notification.save();
 
    res.status(201).json({
      success: true,
      message: 'Project onboarded successfully',
      data: newProject
    });
 
  } catch (err) {
    console.error("Error onboarding project:", err);
    res.status(500).json({
      success: false,
      message: "Server error",
      error: err.message
    });
  }
};

exports.softDeleteProject = async (req, res) => {

  try {

    const { projectId } = req.params;
 
    const project = await Project.findOneAndUpdate(

      { projectId },

      { isDeleted: true },

      { new: true }

    );
 
    if (!project) {

      return res.status(404).json({ message: 'Project not found' });

    }
 
    res.status(200).json({ message: 'Project soft deleted', project });

  } catch (error) {

    res.status(500).json({ message: 'Error deleting project', error });

  }

};

 
 
// Download a specific file from attachments using auto-incremented requisitionId
 const downloadFile = async (req, res) => {
  try {
    const { projectId, fileIndex } = req.params;
 
    const project = await Project.findOne({ projectId });
 
    if (!project) return res.status(404).json({ message: "Project not found" });
 
    if (!project.attachments || project.attachments.length === 0) {
      return res.status(404).json({ message: "No files attached to this project" });
    }
 
    // Ensure the file index is valid
    if (fileIndex < 0 || fileIndex >= project.attachments.length) {
      return res.status(400).json({ message: "Invalid file index" });
    }
 
    const file = project.attachments[fileIndex];
 
    res.set({
      "Content-Type": file.contentType,
      "Content-Disposition": `attachment; filename="${file.filename}"`
    });
 
    return res.send(file.data);
  } catch (error) {
    res.status(500).json({ message: "Error downloading file", error });
  }
}
 
// Get all projects
const getAllProjects = async (req, res) =>
  {  
  try {
    console.log("asdasdasd");
   
    const projects = await Project.find({isDeleted: false}).sort({ createdAt: -1 }); // Most recent first
    const projectwithUrls = projects.map((pro) => {
      return {
        ...pro._doc,
        attachments: pro.attachments.map((file, index) => ({
          filename: file.filename,
          // url: `${req.protocol}s://${req.get("host")}/api/projects/downloadFile/${pro.projectId}/${index}`,
          url: `https://${req.get("host")}/api/projects/downloadFile/${pro.projectId}/${index}`,

        })),
      };
    });
    res.status(200).json(projectwithUrls);
  } catch (error) {
    console.error('Error fetching projects:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch projects', error: error.message });
  }
};
 
const getProjectById = async (req, res) => {
  try {
    const { projectId } = req.params;
 
    // Step 1: Fetch the project (lean returns plain object)
    const project = await Project.findOne({ projectId, isDeleted: false }).lean();
 
    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found"
      });
    }
 
    // Step 2: Fetch all teams associated with this project
    const teams = await Team.find({ projectId, isDeleted: false }).lean();
 
    // Step 3: Add download URLs for attachments (if any)
    // const attachmentUrls = (project.attachments || []).map((file, index) => ({
    //   filename: file.filename,
    //   url: `${req.protocol}://${req.get("host")}/api/projects/downloadFile/${project.projectId}/${index}`
    // }));

       const attachmentUrls = (project.attachments || []).map((file, index) => ({
      filename: file.filename,
      // match with getAllProjects → force https
      url: `https://${req.get("host")}/api/projects/downloadFile/${project.projectId}/${index}`
    }));
 
    // Step 4: Build final response
    const projectWithDetails = {
      ...project,
      attachments: attachmentUrls,
      teamDetails: teams // full array of team documents
    };
 
    res.status(200).json({
      success: true,
      data: projectWithDetails
    });
 
  } catch (error) {
    console.error("Error fetching project:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch project",
      error: error.message
    });
  }
};
 
// Get all projects by clientId
const getAllProjectsByClientId = async (req, res) => {
  try {
    const clientId = req.params.clientId;
    const projects = await Project.find({ clientId ,isDeleted: false}).sort({ createdAt: -1 });
 
    if (projects.length === 0) {
      return res.status(404).json({ message: 'No projects found for this clientId.' });
    }
 
    res.status(200).json(projects);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error });
  }
}
const getTeamEmailsByProjectAndLead =async (req, res) => {
  try {
    const { projectId, teamLeadId } = req.params;
 
    const teams = await Team.find({
      projectId,
      teamLeadId,
      isDeleted: false
    });
 
    if (!teams || teams.length === 0) {
      return res.status(404).json({ message: 'No teams found for this project and team lead' });
    }
 
    const emailSet = new Set();
 
    teams.forEach(team => {
      team.teamMembers.forEach(member => {
        if (member.email) {
          emailSet.add(member.email); // Prevent duplicates
        }
      });
    });
 
    const uniqueEmails = [...emailSet];
 
    res.status(200).json({
      projectId,
      projectName: teams[0].projectName, // Pick from the first matched team
      teamLeadId,
      teamLeadName: teams[0].teamLeadName,
      totalTeams: teams.length,
      totalEmails: uniqueEmails.length,
      emails: uniqueEmails
    });
  } catch (err) {
    console.error('Error fetching team emails:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

const getAllProjectsByTeamLeadId = async (req, res) => {
 
  try {
 
    const teamLeadId = req.params.teamLeadId;
 
    // Fetch only the projects where teamLeadId matches
 
    const projects = await Project.find({ teamLeadId,isDeleted: false });
 
    if (projects.length === 0) {
 
      return res.status(404).json({ message: 'No projects found for this teamLeadId.' });
 
    }
 
    return res.status(200).json(projects);
 
  } catch (error) {
 
    console.error('Error fetching projects:', error);
 
    return res.status(500).json({ message: 'Server error', error });
 
  }
 
};
 



const getAllProjectsByEmployeeOrLeadId = async (req, res) => {
  try {
    const userId = req.params.id;

    // 1. Fetch projects where user is team lead
    const leadProjects = await Project.find({ teamLeadId: userId, isDeleted: false });

    // 2. Fetch teams where user is lead or member
    const teams = await Team.find({
      $or: [
        { teamLeadId: userId },
        { 'teamMembers.memberId': userId }
      ],
      isDeleted: false
    });

    // 3. Extract projectIds from teams
    const teamProjectIds = teams.map(team => team.projectId);

    // 4. Fetch full project details for team projects
    const teamProjects = await Project.find({ projectId: { $in: teamProjectIds }, isDeleted: false });

    // 5. Combine leadProjects + teamProjects (avoid duplicates)
    const combinedProjectsMap = new Map();

    [...leadProjects, ...teamProjects].forEach(project => {
      combinedProjectsMap.set(project.projectId, project);
    });

    const combinedProjects = Array.from(combinedProjectsMap.values());

    if (combinedProjects.length === 0) {
      return res.status(404).json({ message: 'No projects found for this user.' });
    }

    return res.status(200).json({ total: combinedProjects.length, projects: combinedProjects });

  } catch (error) {
    console.error('Error fetching projects:', error);
    return res.status(500).json({ message: 'Server error', error });
  }
};







const updateProjectStatusById = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { status } = req.body;
 
    // Validate input
    if (!projectId || !status) {
      return res.status(400).json({ success: false, message: 'projectId and status are required' });
    }
 
    // Validate allowed statuses
    const allowedStatuses = ['Planned', 'In Progress', 'Completed'];
    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Allowed values: ${allowedStatuses.join(', ')}`
      });
    }
 
    // Prepare update object
    let updateData = { status };
    if (status === 'Completed') {
      updateData.endDate = new Date(); // set endDate only when Completed
    }
 
    // Find and update the project
    const updatedProject = await Project.findOneAndUpdate(
      { projectId },
      updateData,
      { new: true }
    );
 
    if (!updatedProject) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
 
    // Send notification to the Team Lead
    const notification = new Notification({
      recipientId: updatedProject.teamLeadId,
      message: `The status of project "${updatedProject.projectName}" has been updated to "${status}".`,
      link: `/projects/${updatedProject._id}`
    });
 
    await notification.save();
 
    res.status(200).json({
      success: true,
      message: `Project status updated to '${status}'`,
      data: updatedProject
    });
 
  } catch (err) {
    console.error('Error updating project status:', err);
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
}; 




 
// Get all projects with team and members
const getAllProjectsWithTeams = async (req, res) => {
  try {
    // Get all projects
    const projects = await Project.find({isDeleted: false}).sort({ createdAt: -1 });
 
    // Map and attach team details to each project
    const projectsWithTeams = await Promise.all(
      projects.map(async (project) => {
        // Fetch team details based on projectId
        const team = await Team.findOne({
          projectId: project.projectId,
          isDeleted: false,
        });
 
        return {
          projectId: project.projectId,
          clientId: project.clientId,
          projectName: project.projectName,
          category: project.category,
          description: project.description,
          startDate: project.startDate,
          endDate: project.endDate,
          teamLeadId: project.teamLeadId,
          teamLeadName: project.teamLeadName,
          leadId: project.leadId,
          team: project.team,
          attachments: project.attachments,
          status: project.status,
          review: project.review,
          createdAt: project.createdAt,
 
          // Full team details
          teamDetails: team || null,
        };
      })
    );
 
    res.status(200).json({
      success: true,
      message: "Projects fetched successfully with full team details",
      data: projectsWithTeams,
    });
  } catch (error) {
    console.error("Error fetching projects:", error);
    res.status(500).json({
      success: false,
      message: "Server error while fetching projects",
      error: error.message,
    });
  }
};
 
 

 
// Team Lead submits a review to CPC

const updateProject = async (req, res) => {
  try {
    const { projectId } = req.params;
 
    const {
      projectName,
      category,
      description,
      startDate,
      
      expectedEndDate, //  added
      teamLeadId,
      teamLeadName
    } = req.body;
 
    if (!projectId) {
      return res.status(400).json({ success: false, message: "Project ID is required" });
    }
 
    if (!projectName || !category || !description || !startDate  || !teamLeadId) {
      return res.status(400).json({ success: false, message: "All required fields must be provided" });
    }
 
    let attachments = [];
    if (req.files && req.files.length > 0) {
      attachments = req.files.map(file => ({
        filename: file.originalname,
        contentType: file.mimetype,
        data: file.buffer
      }));
    }
 
    // Fetch existing project to check for teamLead change
    const existingProject = await Project.findOne({ projectId });
 
    if (!existingProject) {
      return res.status(404).json({ success: false, message: "Project not found" });
    }
 
    // Check if teamLeadId has changed
    const isTeamLeadChanged = existingProject.teamLeadId !== teamLeadId;
 
    // Update the project
    const updatedProject = await Project.findOneAndUpdate(
      { projectId },
      {
        projectName,
        category,
        description,
        startDate,
       
        expectedEndDate: expectedEndDate || existingProject.expectedEndDate, // 👈 added
        teamLeadId,
        teamLeadName,
        ...(attachments.length > 0 && { attachments })
      },
      { new: true }
    );
 
    // If team lead changed, send notification to new team lead
    if (isTeamLeadChanged) {
      await Notification.create({
        recipientId: teamLeadId,
        message: `You have been assigned as the team lead for project "${projectName}".`,
        link: `/projects/${projectId}`,
      });
    }
 
    res.status(200).json({
      success: true,
      message: "Project updated successfully",
      data: updatedProject
    });
 
  } catch (err) {
    console.error("Error updating project:", err);
    res.status(500).json({ success: false, message: "Server error", error: err.message });
  }
};

const submitReview = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { rating, comment } = req.body;
    // const reviewerId = req.user._id;
    // const userRole = req.user.role;
 
    // if (userRole !== 'Team Lead') {
    //   return res.status(403).json({ message: 'Only Team Leads can submit reviews' });
    // }
 
    const project = await Project.findOne({ projectId });
 
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }
 
    if (project.review && project.review.reviewer) {
      return res.status(400).json({ message: 'Review already submitted for this project' });
    }
 
    project.review = {
      reviewer: reviewerId,
      comment,
      rating,
      reviewedAt: new Date(),
      recipientRole: 'CPC'
    };
 
    await project.save();
    res.status(200).json({ message: 'Review submitted successfully', review: project.review });
 
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
 
// CPC or others view the review
const getReview = async (req, res) => {
  try {
    const { projectId } = req.params;
 
    const project = await Project.findOne({ projectId , isDeleted: false}).lean();
 
    if (!project || !project.review) {
      return res.status(404).json({ message: 'No review found for this project' });
    }
 
    res.status(200).json(project.review);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
 
// Get all projects with tasks
const getProjectsWithTasks = async (req, res) => {
  try {
    const projectsWithTasks = await Project.aggregate([
      {
        $lookup: {
          from: 'tasks', //  collection name (lowercase plural of model name)
          localField: 'projectId',
          foreignField: 'project_id',
          as: 'tasks'
        }
      },
      {
        $match: {
          isDeleted: false,
          status: { $ne: 'Cancelled' }, // Optional: filter by project status
        }
      },
      {
        $sort: { createdAt: -1 } // Optional: sort by newest project
      }
    ]);
 
    res.status(200).json({ success: true, data: projectsWithTasks });
  } catch (error) {
    console.error('Error fetching projects with tasks:', error);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
};
 
// Get projects sorted by end date
const getNearEndingProjects = async (req, res) => {
   try {
    const projects = await Project.find({isDeleted: false})
      .lean()
      .sort({ endDate: 1 }); // Ascending (earliest end date first)
 
    res.status(200).json({ success: true, count: projects.length, projects });
  } catch (error) {
    console.error('Error fetching sorted projects:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};
 



const softDeleteProjectById = async (req, res) => {
  try {
    const { projectId } = req.params;
 
    const project = await Project.findOne({ projectId, isDeleted: false });
 
    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found or already deleted.' });
    }
 
    // Soft delete the project
    project.isDeleted = true;
    await project.save();
 
    // Soft delete related teams
    await Team.updateMany(
      { projectId, isDeleted: false },
      { $set: { isDeleted: true } }
    );
 
    // Soft delete related tasks
    await Task.updateMany(
      { projectId, isDeleted: false },
      { $set: { isDeleted: true } }
    );
 
    // Soft delete related bugs
    await Bug.updateMany(
      { projectId, isDeleted: false },
      { $set: { isDeleted: true } }
    );
   await ProjectMom.updateMany(
      { projectId, isDeleted: false },
      { $set: { isDeleted: true } }
    );
    return res.status(200).json({
      success: true,
      message: 'Project, teams, tasks, and bugs soft deleted successfully.'
    });
  } catch (error) {
    console.error('Error during soft delete:', error);
    return res.status(500).json({ success: false, message: 'Server Error during soft delete.' });
  }
};



const getProjectSummary = async (req, res) => {
  try {
    const { projectId } = req.params;
 
    if (!projectId) {
      return res.status(400).json({ message: 'projectId is required' });
    }
 
    //  Team Count
    const teamCount = await Team.countDocuments({
      projectId: projectId,
      $or: [{ isDeleted: false }, { isDeleted: { $exists: false } }]
    });
 
    //  Task Status Count
    const taskStatus = await Task.aggregate([
      {
        $match: {
          projectId: projectId,
          $or: [{ isDeleted: false }, { isDeleted: { $exists: false } }]
        }
      },
      {
        $group: { _id: '$status', count: { $sum: 1 } }
      }
    ]);
 
    const taskStatusCounts = { Pending: 0, 'In Progress': 0, Completed: 0 };
    taskStatus.forEach(item => {
      if (item._id) taskStatusCounts[item._id] = item.count;
    });
 
    //  Bug Status Count
    const bugStatus = await Bug.aggregate([
      {
        $match: {
          projectId: projectId,
          $or: [{ isDeleted: false }, { isDeleted: { $exists: false } }]
        }
      },
      {
        $group: { _id: '$status', count: { $sum: 1 } }
      }
    ]);
 
    const bugStatusCounts = { Open: 0, Resolved: 0, Closed: 0 };
    bugStatus.forEach(item => {
      if (item._id) bugStatusCounts[item._id] = item.count;
    });
 
    // MOM Count (Total, Online, Offline)
    const momAggregation = await Mom.aggregate([
      {
        $match: {
          projectId: projectId,
          $or: [{ isDeleted: false }, { isDeleted: { $exists: false } }]
        }
      },
      {
        $group: {
          _id: '$meetingMode',
          count: { $sum: 1 }
        }
      }
    ]);
 
    let onlineCount = 0;
    let offlineCount = 0;
 
    momAggregation.forEach(item => {
      const mode = item._id?.toLowerCase();
      if (mode === 'online') onlineCount = item.count;
      if (mode === 'offline') offlineCount = item.count;
    });
 
    const momCount = onlineCount + offlineCount;
 
    //  Document Count
    const documentCount = await Document.countDocuments({
      projectId: projectId,
      $or: [{ isDeleted: false }, { isDeleted: { $exists: false } }]
    });
 
    //  Final Response
    res.status(200).json({
      projectId,
      summary: {
        teamCount,
        taskStatusCounts,
        bugStatusCounts,
        mom: {
          total: momCount,
          online: onlineCount,
          offline: offlineCount
        },
        documentCount
      }
    });
  } catch (error) {
    console.error('Error fetching project summary:', error);
    res.status(500).json({
      message: 'Error fetching project summary',
      error: error.message
    });
  }
};
 const getEmployeeProjectSummary = async (req, res) => {
  try {
    const { projectId, employeeId } = req.params;
 
    if (!projectId || !employeeId) {
      return res.status(400).json({ message: 'projectId and employeeId are required' });
    }
 
    //  Team Count (where employee is a member or lead)
    const teamCount = await Team.countDocuments({
      projectId,
      $or: [
        { members: employeeId },
        { teamLead: employeeId }
      ],
      $or: [{ isDeleted: false }, { isDeleted: { $exists: false } }]
    });
 
    //  Task Status Count (assigned to employee)
    const taskStatus = await Task.aggregate([
      {
        $match: {
          projectId,
          assignedTo: employeeId,
          $or: [{ isDeleted: false }, { isDeleted: { $exists: false } }]
        }
      },
      {
        $group: { _id: '$status', count: { $sum: 1 } }
      }
    ]);
 
    const taskStatusCounts = { Pending: 0, 'In Progress': 0, Completed: 0 };
    taskStatus.forEach(item => {
      if (item._id) taskStatusCounts[item._id] = item.count;
    });
 
    //  Bug Status Count (reported or assigned to employee)
    const bugStatus = await Bug.aggregate([
      {
        $match: {
          projectId,
          $or: [
            { reportedBy: employeeId },
            { assignedTo: employeeId }
          ],
          $or: [{ isDeleted: false }, { isDeleted: { $exists: false } }]
        }
      },
      {
        $group: { _id: '$status', count: { $sum: 1 } }
      }
    ]);
 
    const bugStatusCounts = { Open: 0, Resolved: 0, Closed: 0 };
    bugStatus.forEach(item => {
      if (item._id) bugStatusCounts[item._id] = item.count;
    });
 
    //  MOM Count (employee attended or created)
    const momAggregation = await Mom.aggregate([
      {
        $match: {
          projectId,
          $or: [
            { createdBy: employeeId },
            { attendees: employeeId }
          ],
          $or: [{ isDeleted: false }, { isDeleted: { $exists: false } }]
        }
      },
      {
        $group: {
          _id: '$meetingMode',
          count: { $sum: 1 }
        }
      }
    ]);
 
    let onlineCount = 0;
    let offlineCount = 0;
 
    momAggregation.forEach(item => {
      const mode = item._id?.toLowerCase();
      if (mode === 'online') onlineCount = item.count;
      if (mode === 'offline') offlineCount = item.count;
    });
 
    const momCount = onlineCount + offlineCount;
 
    //  Document Count (uploaded or shared with employee)
    const documentCount = await Document.countDocuments({
      projectId,
      $or: [
        { uploadedBy: employeeId },
        { sharedWith: employeeId }
      ],
      $or: [{ isDeleted: false }, { isDeleted: { $exists: false } }]
    });
 
    // Final Response
    res.status(200).json({
      projectId,
      employeeId,
      summary: {
        teamCount,
        taskStatusCounts,
        bugStatusCounts,
        mom: {
          total: momCount,
          online: onlineCount,
          offline: offlineCount
        },
        documentCount
      }
    });
  } catch (error) {
    console.error('Error fetching employee project summary:', error);
    res.status(500).json({
      message: 'Error fetching employee project summary',
      error: error.message
    });
  }
};
module.exports = {getEmployeeProjectSummary,getProjectSummary,softDeleteProjectById,getNearEndingProjects,getTeamEmailsByProjectAndLead,getProjectsWithTasks,getAllProjectsByEmployeeOrLeadId, getReview,submitReview,createProject,getAllProjectsByTeamLeadId,getAllProjects ,downloadFile, getProjectById, getAllProjectsByClientId,updateProjectStatusById,getAllProjectsWithTeams,updateProject };
 
 