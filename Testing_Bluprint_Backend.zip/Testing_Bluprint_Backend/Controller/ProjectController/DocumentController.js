// controllers/documentController.js
const Document = require('../../Model/ProjectModel/documentModel');
const Project = require('../../Model/ProjectModel/projectModel');
const path = require('path');
const fs = require('fs');

// Upload a document
exports.uploadDocument = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { name, description } = req.body;

    // Check if file is uploaded
    if (!req.file) {
      return res.status(400).json({ success: false, message: "No file uploaded" });
    }

    // Ensure project exists
    const project = await Project.findOne({ projectId, isDeleted: false });
    if (!project) {
      // Remove uploaded file if project not found
      fs.unlinkSync(req.file.path);
      return res.status(404).json({ success: false, message: "Project not found" });
    }

    // Generate documentId: <First3LettersOfProjectName>-DOC-001
    const prefix = project.projectName.slice(0, 3).toUpperCase();

    // Find last document for this project
    const lastDoc = await Document.find({ projectId })
      .sort({ uploadedAt: -1 })
      .limit(1);

    let newNumber = 1;
    if (lastDoc.length > 0) {
      const lastId = lastDoc[0].documentId; // e.g., ABC-DOC-005
      const parts = lastId.split('-');
      newNumber = parseInt(parts[2]) + 1;
    }

    const documentId = `${prefix}-DOC-${String(newNumber).padStart(3, '0')}`;

    // Save document in DB
    const document = new Document({
      documentId,
      projectId,
      name,
      description,
      filePath: req.file.path,
     isDeleted: false
    });

    await document.save();

    res.status(200).json({
      success: true,
      message: "Document uploaded successfully",
      document,
    });

  } catch (error) {
    console.error("Upload error:", error);
    res.status(500).json({ success: false, message: "Server error", error: error.message });
  }
};


// exports.uploadDocument = async (req, res) => {
//   try {
//     const { projectId } = req.params;
//     const { name, description } = req.body;

//     // 1. Validate file
//     if (!req.file) {
//       return res.status(400).json({ success: false, message: "No file uploaded" });
//     }

//     // 2. Ensure project exists
//     const project = await Project.findOne({ projectId, isDeleted: false });
//     if (!project) {
//       // remove uploaded file if project not found
//       fs.unlinkSync(req.file.path);
//       return res.status(404).json({ success: false, message: "Project not found" });
//     }

//     // 3. Generate documentId like ABC-DOC-001
//     const prefix = project.projectName.slice(0, 3).toUpperCase();

//     const lastDoc = await Document.find({ projectId })
//       .sort({ uploadedAt: -1 })
//       .limit(1);

//     let newNumber = 1;
//     if (lastDoc.length > 0) {
//       const lastId = lastDoc[0].documentId; // e.g., ABC-DOC-005
//       const parts = lastId.split("-");
//       newNumber = parseInt(parts[2]) + 1;
//     }

//     const documentId = `${prefix}-DOC-${String(newNumber).padStart(3, "0")}`;

//     // 4. Save relative path (not absolute system path)
//     // const relativePath = path.relative(process.cwd(), req.file.path);
//     const relativePath = path.join("uploads", path.basename(req.file.path));


//     // 5. Save document
//     const document = new Document({
//       documentId,
//       projectId,
//       name,
//       description,
//       filePath: relativePath,
//       isDeleted: false,
//       uploadedAt: new Date(),
//     });

//     await document.save();

//     res.status(200).json({
//       success: true,
//       message: "Document uploaded successfully",
//       document,
//     });
//   } catch (error) {
//     console.error("Upload error:", error);
//     res.status(500).json({
//       success: false,
//       message: "Server error",
//       error: error.message,
//     });
//   }
// };



exports.viewDocument = async (req, res) => {
  try {
    const { documentId } = req.params;
 
    // 1. Find the document in DB
    const docRecord = await Document.findOne({ documentId, isDeleted: false });
    if (!docRecord) {
      return res.status(404).json({ message: "Document not found." });
    }
 
    // 2. Build file path (assuming you stored relative path in DB like: uploads/docs/filename.ext)
    const filePath = path.resolve(process.cwd(), docRecord.filePath);
    console.log("Serving file from:", filePath);
 
    // 3. Check if file exists
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "File not found on server." });
    }
 
    // 4. Detect content type automatically
    const mime = require("mime-types");
    const contentType = mime.lookup(filePath) || "application/octet-stream";
 
    res.setHeader("Content-Type", contentType);
    res.setHeader(
      "Content-Disposition",
      `inline; filename="${path.basename(filePath)}"`
    );
 
    // 5. Stream the file
    fs.createReadStream(filePath).pipe(res);
  } catch (error) {
    console.error("Error viewing document:", error);
    res
      .status(500)
      .json({ message: "Failed to view document", error: error.message });
  }
};



// Get all documents for a project
// exports.getDocumentsByProject = async (req, res) => {
//   try {
//     const { projectId } = req.params;

//     // Fetch documents sorted by uploadedAt descending (latest first)
//     const docs = await Document.find({ projectId ,}).sort({ uploadedAt: -1 });

//     res.status(200).json({ success: true, documents: docs });
//   } catch (error) {
//     console.error("Fetch error:", error);
//     res.status(500).json({ success: false, message: "Server error", error: error.message });
//   }
// };
exports.getDocumentsByProject = async (req, res) => {
  try {
    const { projectId } = req.params;

    // Fetch documents where isDeleted is false, sorted by uploadedAt descending
    const docs = await Document.find({ 
      projectId, 
      isDeleted: false 
    }).sort({ uploadedAt: -1 });

    res.status(200).json({ success: true, documents: docs });
  } catch (error) {
    console.error("Fetch error:", error);
    res.status(500).json({ success: false, message: "Server error", error: error.message });
  }
};

// Soft delete a document by documentId
exports.softDeleteDocument = async (req, res) => {
  try {
    const { documentId } = req.params;

    // Find document
    const document = await Document.findOne({ documentId });
    if (!document) {
      return res.status(404).json({ success: false, message: "Document not found" });
    }

    // Soft delete by setting isDeleted to true
    document.isDeleted = true;
    await document.save();

    res.status(200).json({
      success: true,
      message: `Document ${documentId} deleted successfully`,
    });
  } catch (error) {
    console.error("Soft delete error:", error);
    res.status(500).json({ success: false, message: "Server error", error: error.message });
  }
};
