



// // HrmsController.js
// const transporter=require("../../middlewares/nodemailer");
// const bcrypt = require("bcrypt");
// const crypto = require("crypto");
// const jwt = require("jsonwebtoken");
// //const transporter = require("../../middlewares/nodemailer");
// const sessionService = require('../../middlewares/sessionServices');
//  const {sendEmail}=require('../../middlewares/nodemailer')
// const { connections } = require("../../Config/db");
// const getEmployeeModel = require("../../Model/HrmsModel/HrmsModel");
// const getDepartmentModel=require("../../Model/HrmsModel/HrmsModel")
// const fetchAllUser=require("../../Model/HrmsModel/HrmsModel");
// const sendOtpForLogin=require("../../Model/HrmsModel/HrmsModel");
// const verifyLoginOTP=require("../../Model/HrmsModel/HrmsModel");
// const getOtpVerificationModel = require("../../Model/HrmsModel/OtpVerificationModel");
// const path = require("path");

 
// exports.getAllHRMSEmployees = async (req, res) => {
//   try {
//     const { Employee } = getEmployeeModel(connections.hrms);
//     const { Department } = getDepartmentModel(connections.hrms); // Assuming this exists
 
//     // First find the IT department's _id
//     const itDept = await Department.findOne({ name: 'IT' });
 
//     if (!itDept) {
//       return res.status(404).json({ message: 'IT department not found' });
//     }
 
//     const employees = await Employee.find({ department: itDept._id });
 
//     res.status(200).json(employees);
//   } catch (error) {
//     console.error("Failed to fetch IT department employees:", error);
//     res.status(500).json({ message: "Error fetching employees", error });
//   }
// };
 
 
// exports.fetchAllUsers = async (req, res) => {
//   try{
//     const { User } = fetchAllUser(connections.hrms);
//       const users = await User.find({isDeleted: false});
//       if(!users || users.length === 0){
//           return res.status(400).json({message:"USER NOT FOUND"});
//       }
//       // Map through the users array and extract the relevant fields
//       const userDetails = users.map(user => ({
//           fullName: user.fullName,
//           email: user.email,
//           username: user.username,
//           contact: user.contact,
//           role: user.role,
//           id: user.userId,
//           profilePicture: user.profilePicture,
//           filetype: user.profileImageType,
//           isDeleted: user.isDeleted,
//           rolePriority: user.rolePriority
//       }));
 
//      // userDetails.sort((a, b) => a.rolePriority - b.rolePriority);
     
//       return res.status(200).json(userDetails);
//   }catch(error) {
//       console.log(error);
//       return res.status(500).json({message:"Server Error", error});
//   }
// };
 
 
// const validateEmailFormat = (email) => {
//   const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//   return emailRegex.test(email);
// }
 
 
 
 
 
 
 
// exports.sendOtpForLogin = async (req, res) => {
//   try {
//     const { email, password } = req.body;
//     const { User } = sendOtpForLogin(connections.hrms); // HRMS DB (read-only)
//     const OtpVerification = getOtpVerificationModel(connections.main); // Main DB (writable)
 
//     // Validate email format
//     if (!validateEmailFormat(email)) {
//       return res.status(400).json({ message: "Invalid email format" });
//     }
 
//     // Find user in HRMS DB
//     const user = await User.findOne({ email, isDeleted: false });
//     if (!user) {
//       return res.status(404).json({ message: "Email does not exist" });
//     }
 
//     // Check existing OTP record in Main DB
//     let otpRecord = await OtpVerification.findOne({ email });
 
//     // Check if account is frozen
//     if (otpRecord && otpRecord.freezeUntil && otpRecord.freezeUntil > Date.now()) {
//       return res.status(400).json({
//         message: "Your account is currently frozen. Please try again later.",
//       });
//     }
 
//     // Check password
//     const isPasswordMatch = await user.comparePassword(password);
//     if (!isPasswordMatch) {
//       if (!otpRecord) {
//         otpRecord = await OtpVerification.create({ email, failedAttempts: 0 });
//       }
//       otpRecord.failedAttempts += 1;
//       if (otpRecord.failedAttempts >= 3) {
//         otpRecord.freezeUntil = Date.now() + 15 * 60 * 1000; // 15 mins
//       }
//       await otpRecord.save();
//       return res.status(401).json({
//         message: "Invalid credentials: either email or password",
//       });
//     }
 
//     // Generate OTP
//     const otp = crypto.randomInt(100000, 999999).toString();
//     const hashedLoginOtp = await bcrypt.hash(otp, 10);
//     const tokenExpireTime = Date.now() + 10 * 60 * 1000;//token expried at 10 minutes from now
 
//     // Update or create OTP record
//     if (otpRecord) {
//       otpRecord.loginOTP = hashedLoginOtp;
//       otpRecord.tokenExpireTime = tokenExpireTime;
//       otpRecord.failedAttempts = 0;
//       otpRecord.freezeUntil = null;
//       await otpRecord.save();
//     } else {
//       await OtpVerification.create({
//         email,
//         loginOTP: hashedLoginOtp,
//         tokenExpireTime,
//         failedAttempts: 0,
//         freezeUntil: null,
//       });
//     }
 
//     // HTML Email Template
//     const emailContentForLogin = `
//       <html>
//         <body style="font-family: Arial, sans-serif; color: #333;">
//           <p>We received a request for Login. To complete the login, please use the following One-Time-Password (OTP):</p>
//           <p style="font-size: 20px; text-align:center; font-weight: bold; color:rgb(68, 152, 231);">${otp}</p>
//           <p>This OTP is valid for the next 10 minutes. Please do not share this OTP with anyone for security reasons.</p>
//           <p>If you did not request this, please ignore this email.</p>
//           <p>Thank you for using our service!</p>
//           <p>Best Regards,<br>AAS International</p>
//         </body>
//       </html>
//     `;
 
//     // Email sending
//     // const mailingOptions = {
//     //   from: process.env.EMAIL_ID,
//     //   to: user.email,
//     //   subject: "Your HRMS Login OTP: Secure Access Code Inside",
//     //   html: emailContentForLogin,
//     // };
 
//     await sendEmail('Login OTP',emailContentForLogin,email);
 
//     return res.status(200).json({
//       message: "OTP sent successfully",
//       // user: {
//       //   email: user.email,
//       //   username: user.username,
//       //   fullName: user.fullName,
//       //   role: user.role,
//       //   userId: user.userId,
//       // },
//     });
//   } catch (error) {
//     console.error("Send OTP Error:", error);
//     return res.status(500).json({ message: "Invalid Credenetials", error });
//   }
// };
 
 
 
//  const generateRefreshToken = (payload) => {
//   return jwt.sign(payload, process.env.JWT_SECRET_KEY, { expiresIn: "7d" }); // refresh valid for 7 days
// };

 
 
// const generateToken = (payload) => {
//     return jwt.sign(payload, process.env.JWT_SECRET_KEY, { expiresIn: "1m" });
// };
 
 
// // exports.verifyLoginOTP = async (req, res) => {
// //   try {
// //     const { email, otp } = req.body;
// //     const { User, Employee } = verifyLoginOTP(connections.hrms);
// //     const Session = require('../../Model/HrmsModel/sessionModel')(connections.main);
// //     const OtpVerification = getOtpVerificationModel(connections.main);
 
// //     // Initialize session service
// //     const { verifyOTPAndCreateSession } = sessionService(User, Session, OtpVerification);
 
// //     // Get device info and IP address from request
// //     const deviceInfo = req.headers['user-agent'] || 'Unknown';
// //     const ipAddress = req.ip || 'Unknown';
// //     const token=generateToken({id:User._id,role:User.role})
// //     // Verify OTP and create session
// //     // console.log(token);
   
// //     const { session, user } = await verifyOTPAndCreateSession(email, otp, deviceInfo, ipAddress);
 
// //     // Find employee data
// //     const employee = await Employee.findOne({ email });
// //     const employeeID = employee ? employee.employeeID : null;
 
// //     // Set session token in HTTP-only cookie
// //     res.cookie('token', token, {
// //       httpOnly: true,
// //       secure: true,
// //       maxAge:  24 * 60 * 60 * 1000, // 1 days
// //       sameSite: 'None',
// //       path: '/',
// //     });
// //     res.cookie('email', email, {
// //       httpOnly: true,
// //       secure: true,
// //       maxAge: 24 * 60 * 60 * 1000, // 1days
// //       sameSite: 'None',
// //       path: '/',
// //     });
 
// //     return res.status(200).json({
// //       message: 'Login successful',
     
// //     });
// //   } catch (error) {
// //     console.error('OTP Verification Error:', error.message);
// //     return res.status(400).json({ message: error.message });
// //   }
// // };
 


// // exports.verifyLoginOTP = async (req, res) => {
// //   try {
// //     const { email, otp } = req.body;
// //     const { User, Employee } = verifyLoginOTP(connections.hrms);
// //     const Session = require('../../Model/HrmsModel/sessionModel')(connections.main);
// //     const OtpVerification = getOtpVerificationModel(connections.main);

// //     // Initialize session service
// //     const { verifyOTPAndCreateSession } = sessionService(User, Session, OtpVerification);

// //     // Device/IP
// //     const deviceInfo = req.headers['user-agent'] || 'Unknown';
// //     const ipAddress = req.ip || 'Unknown';

// //     // Verify OTP and create session
// //     const { session, user } = await verifyOTPAndCreateSession(email, otp, deviceInfo, ipAddress);

// //     // Create Access + Refresh tokens
// //     const accessToken = generateToken({ id: user._id, role: user.role });
// //     const refreshToken = generateRefreshToken({ id: user._id, role: user.role });

// //     // Save refresh token in DB (optional but recommended for security/revocation)
// //     session.refreshToken = refreshToken;
// //     await session.save();

// //     // Set cookies
// //     res.cookie('token', accessToken, {
// //       httpOnly: false,
// //       secure: false,
// //       maxAge: 24 * 60 * 60 * 1000, // 1 day
// //       sameSite: 'lax',
// //       path: '/',
// //     });

// //     res.cookie('refreshToken', refreshToken, {
// //       httpOnly: false,
// //       secure: false,
// //       maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
// //       sameSite: 'lax',
// //       path: '/',
// //     });
// //     res.cookie('email', email, {
// //       httpOnly: false,
// //       secure: false,
// //       maxAge: 24 * 60 * 60 * 1000, // 1days
// //       sameSite: 'lax',
// //       path: '/',
// //     });

// //     return res.status(200).json({
// //       message: 'Login successful',
// //       accessToken,
// //       refreshToken,
// //     });
// //   } catch (error) {
// //     console.error('OTP Verification Error:', error.message);
// //     return res.status(400).json({ message: error.message });
// //   }
// // };



// // exports.refreshAccessToken = async (req, res) => {
// //   try {
// //     const refreshToken = req.cookies.refreshToken || req.body.refreshToken;
// //     if (!refreshToken) {
// //       return res.status(401).json({ message: "Refresh token missing" });
// //     }

// //     // Verify refresh token
// //     jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET_KEY, async (err, decoded) => {
// //       if (err) {
// //         return res.status(403).json({ message: "Invalid refresh token" });
// //       }

// //       // Optional: check if refresh token exists in DB/session
// //       const Session = require('../../Model/HrmsModel/sessionModel')(connections.main);
// //       const session = await Session.findOne({ refreshToken });
// //       if (!session) {
// //         return res.status(403).json({ message: "Refresh token not recognized" });
// //       }

// //       // Generate new access token
// //       const newAccessToken = generateToken({ id: decoded.id, role: decoded.role });

// //       res.cookie('token', newAccessToken, {
// //         httpOnly: true,
// //         secure: true,
// //         maxAge: 24 * 60 * 60 * 1000, // 1 day
// //         sameSite: 'None',
// //         path: '/',
// //       });

// //       return res.status(200).json({
// //         message: "Access token refreshed",
// //         accessToken: newAccessToken,
// //       });
// //     });
// //   } catch (error) {
// //     console.error("Refresh token error:", error.message);
// //     return res.status(500).json({ message: "Failed to refresh token" });
// //   }
// // };

// // ---------------------- Unified Controller ----------------------
// // ---------------------- Verify OTP + Refresh Token Controller ----------------------
// // exports.verifyLoginOTP = async (req, res) => {
// //   try {
// //     const { email, otp } = req.body;
// //     const refreshTokenFromClient = req.cookies.refreshToken || req.body.refreshToken;

// //     // ---------------- Case 1: OTP Login Flow ----------------
// //     if (email && otp) {
// //       const { User } = verifyLoginOTP(connections.hrms);
// //       const Session = require("../../Model/HrmsModel/sessionModel")(connections.main);
// //       const OtpVerification = getOtpVerificationModel(connections.main);

// //       // Init session service
// //       const { verifyOTPAndCreateSession } = sessionService(User, Session, OtpVerification);

// //       // Device/IP tracking
// //       const deviceInfo = req.headers["user-agent"] || "Unknown";
// //       const ipAddress = req.ip || "Unknown";

// //       // Verify OTP
// //       const { session, user } = await verifyOTPAndCreateSession(email, otp, deviceInfo, ipAddress);

// //       // Generate tokens
// //       const accessToken = generateToken({ id: user._id, role: user.role });
// //       const refreshToken = generateRefreshToken({ id: user._id, role: user.role });

// //       // Save refresh token in session DB
// //       session.refreshToken = refreshToken;
// //       await session.save();

// //       // Set cookies
// //       res.cookie("token", accessToken, {
// //         httpOnly: false,
// //         secure: false,
// //         sameSite: "lax",
// //         path: "/",
// //         maxAge: 24 * 60 * 60 * 1000,
// //       });

// //       res.cookie("refreshToken", refreshToken, {
// //         httpOnly: false,
// //         secure: false,
// //         sameSite: "lax",
// //         path: "/",
// //         maxAge: 7 * 24 * 60 * 60 * 1000,
// //       });

// //       res.cookie("email", email, {
// //         httpOnly: false,
// //         secure: false,
// //         sameSite: "lax",
// //         path: "/",
// //         maxAge: 24 * 60 * 60 * 1000,
// //       });

// //       return res.status(200).json({
// //         message: "Login successful",
// //         accessToken,
// //         refreshToken,
// //       });
// //     }

// //     // ---------------- Case 2: Refresh Token Flow ----------------
// //     if (refreshTokenFromClient) {
// //       jwt.verify(
// //         refreshTokenFromClient,
// //         process.env.JWT_REFRESH_SECRET_KEY,
// //         async (err, decoded) => {
// //           if (err) {
// //             return res.status(403).json({ message: "Invalid refresh token" });
// //           }

// //           // Check refresh token in DB
// //           const Session = require("../../Model/HrmsModel/sessionModel")(connections.main);
// //           const session = await Session.findOne({ refreshToken: refreshTokenFromClient });
// //           if (!session) {
// //             return res.status(403).json({ message: "Refresh token not recognized" });
// //           }

// //           // Generate new access token
// //           const newAccessToken = generateToken({ id: decoded.id, role: decoded.role });

// //           res.cookie("token", newAccessToken, {
// //             httpOnly: true,
// //             secure: true,
// //             sameSite: "None",
// //             path: "/",
// //             maxAge: 24 * 60 * 60 * 1000,
// //           });

// //           return res.status(200).json({
// //             message: "Access token refreshed",
// //             accessToken: newAccessToken,
// //           });
// //         }
// //       );
// //       return;
// //     }

// //     // ---------------- If neither OTP nor refreshToken is provided ----------------
// //     return res.status(400).json({ message: "Invalid request. Provide OTP or refresh token." });
// //   } catch (error) {
// //     console.error("verifyLoginOTP Controller Error:", error.message);
// //     return res.status(500).json({ message: "Server Error" });
// //   }
// // };

 
// exports.verifyLoginOTP = async (req, res) => {
//   try {
//     const { email, otp } = req.body;
//     const refreshTokenFromClient = req.cookies.refreshToken || req.body.refreshToken;

//     // ---------------- Case 1: OTP Login Flow ----------------
//     if (email && otp) {
//       const { User } = verifyLoginOTP(connections.hrms);
//       const Session = require("../../Model/HrmsModel/sessionModel")(connections.main);
//       const OtpVerification = getOtpVerificationModel(connections.main);

//       const { verifyOTPAndCreateSession } = sessionService(User, Session, OtpVerification);

//       const deviceInfo = req.headers["user-agent"] || "Unknown";
//       const ipAddress = req.ip || "Unknown";

//       const { session, user } = await verifyOTPAndCreateSession(email, otp, deviceInfo, ipAddress);

//       const accessToken = generateToken({ id: user._id });
//       const refreshToken = generateRefreshToken({ id: user._id });

//       // session.refreshToken = refreshToken;
//       // await session.save();

//       res.cookie("token", accessToken, {
//         httpOnly: true,
//         secure: true,
//         sameSite: "None",
//         path: "/",
//         // maxAge: 24* 60 * 60 * 1000,
//         maxAge:60*1000
//       });

//       res.cookie("refreshToken", refreshToken, {
//         httpOnly: false,
//         secure: false,
//         sameSite: "lax",
//         path: "/",
//         maxAge: 7 * 24 * 60 * 60 * 1000,
//       });

//       res.cookie("email", email, {
//         httpOnly: false,
//         secure: true,
//         sameSite: "None",
//         path: "/",
//         maxAge: 24 * 60 * 60 * 1000,
//       });

//       return res.status(200).json({
//         message: "Login successful",
//         accessToken,
//         refreshToken,
//       });
//     }

//     // ---------------- Case 2: Refresh Token Flow ----------------
//     if (refreshTokenFromClient) {
//       try{
//       // jwt.verify(refreshTokenFromClient, process.env.JWT_SECRET_KEY, async (err, decoded) => {
//         // if (err) return res.status(401).json({ message: "Invalid or expired refresh token" });

//         // const Session = require("../../Model/HrmsModel/sessionModel")(connections.main);
//         // const session = await Session.findOne({ refreshToken: refreshTokenFromClient });
//         // if (!session) return res.status(403).json({ message: "Refresh token not recognized" });
//   const decoded = jwt.verify(refreshTokenFromClient, process.env.JWT_SECRET_KEY);
//         const newAccessToken = generateToken({ id: decoded.id, role: decoded.role });

//         res.cookie("token", newAccessToken, {
//           httpOnly: true,
//           secure: true,
//           sameSite: "None",
//           path: "/",
//           // maxAge: 24 * 60 * 60 * 1000,
//            maxAge: 60 * 1000,
//         });
//         req.user = decoded; 
//         return res.status(200).json({
//           message: "Access token refreshed",
//           accessToken: newAccessToken,
//         });
  
//       }
//     catch (err) {
//         return res.status(403).json({ message: "Invalid or expired refresh token." });
//       }
//     }

//     return res.status(400).json({ message: "Invalid request. Provide OTP or refresh token." });
//   } catch (error) {
//     console.error("verifyLoginOTP Error:", error.message);
//     return res.status(500).json({ message: "Server Error" });
//   }
// };



// exports.getUserByEmail = async (req, res) => {
//   try {
//     const { email } = req.params; // Expect email in request body
//     const { User, Employee } = verifyLoginOTP(connections.hrms);
 
//     // Find user in HRMS DB
//     const user = await User.findOne({ email }).select('-password'); // Exclude password
//     if (!user) {
//       return res.status(404).json({ message: "User not found" });
//     }
 
//     const employee = await Employee.findOne({ email });
//     const employeeData = employee ? employee.toObject() : null;
 
 
 
//     // Return only the message for consistency
//     return res.status(200).json({ message: "User data retrieved successfully", user , employeeData});
//   } catch (error) {
//     console.error("User Fetch Error:", error);
//     return res.status(500).json({ message: "Error fetching user data" });
//   }
// };
 
 

 
// exports.logout = async (req, res) => {
//   try {
//     const cookieOptions = {
//       httpOnly: true,
//       secure: true, // set to true if using HTTPS in production
//       sameSite: 'None',
//       path: '/',
//     };
 
//     res.clearCookie('token', cookieOptions);
//     res.clearCookie('email', cookieOptions);
//     res.clearCookie('refreshToken', cookieOptions);
 
//     return res.status(200).json({ message: "Logout successful" });
//   } catch (error) {
//     console.error("Logout Error:", error);
//     return res.status(500).json({ message: "Error logging out", error: error.message });
//   }
// };
 
 
// exports.logoutAllDevices = async (req, res) => {
//   try {
//     const email = req.cookies.email || req.body.email;
//     if (!email) {
//       return res.status(400).json({ message: 'Email required for logout' });
//     }
 
//     const Session = require('../../Model/HrmsModel/sessionModel')(connections.main);
//     const { deleteAllSessions } = sessionService(null, Session, null);
 
//     await deleteAllSessions(email);
 
//     res.clearCookie('sessionToken', {
//       httpOnly: true,
//       secure: process.env.NODE_ENV === 'production',
//       sameSite: 'None',
//     });
//     res.clearCookie('email', {
//       httpOnly: true,
//       secure: process.env.NODE_ENV === 'production',
//       sameSite: 'None',
//     });
 
//     return res.status(200).json({ message: 'Successfully logged out from all devices' });
//   } catch (error) {
//     console.error('Logout All Devices Error:', error);
//     return res.status(500).json({ message: 'Error logging out from all devices', error: error.message });
//   }
// };
 
// // controllers/userController.js
// exports.getUserByEmailFromCookie = async (req, res) => {
//   try {
//     const email = req.cookies.email; // Fetch email from cookies
//     if (!email) {
//       return res.status(400).json({ message: "Email cookie is missing" });
//     }
 
//     const { User, Employee } = verifyLoginOTP(connections.hrms);
 
//     const user = await User.findOne({ email }).select('-password');
//     if (!user) {
//       return res.status(404).json({ message: "User not found" });
//     }
 
//     const employee = await Employee.findOne({ email });
//     const employeeData = employee ? employee.toObject() : null;
 
//     return res.status(200).json({
//       message: "User and employee data retrieved successfully",
//       user,
//       employee: employeeData,
//     });
//   } catch (error) {
//     console.error("Fetch User by Cookie Error:", error);
//     return res.status(500).json({ message: "Error fetching user data", error: error.message });
//   }
// };
 
 
 
// exports.checkToken = async (req, res) => {
//     try{
       
//         const token  = req.cookies.token;
       
       
//         const isPresent = !!token;
 
//         if(!isPresent){
//             return res.status(200).json({message: "Token is not present", dashboard: false});
//         }
//         return res.status(200).json({message: "Token is present", dashboard: true});
 
//     }catch(error){
//         console.log(error);
//         return res.status(500).json({message: "Internal Server error, please try again later", error: error.message});
//     }
// }







// HrmsController.js
const transporter=require("../../middlewares/nodemailer");
const bcrypt = require("bcrypt");
const path = require("path");
const crypto = require("crypto");
const nodemailer = require("nodemailer");
const jwt = require("jsonwebtoken");
//const transporter = require("../../middlewares/nodemailer");
const sessionService = require('../../middlewares/sessionServices');
//  const {sendEmail}=require('../../middlewares/nodemailer')
const { connections } = require("../../Config/db");
const getEmployeeModel = require("../../Model/HrmsModel/HrmsModel");
const getDepartmentModel=require("../../Model/HrmsModel/HrmsModel")
const fetchAllUser=require("../../Model/HrmsModel/HrmsModel");
const sendOtpForLogin=require("../../Model/HrmsModel/HrmsModel");
const verifyLoginOTP=require("../../Model/HrmsModel/HrmsModel");
const getOtpVerificationModel = require("../../Model/HrmsModel/OtpVerificationModel");
const Profile=require("../../Model/HrmsModel/Profile")
const {sendEmail}=require("../../middlewares/nodemailer")


// const path = require("path");
const mime = require("mime-types");
const fs = require("fs");

 
exports.getAllHRMSEmployees = async (req, res) => {
  try {
    const { Employee } = getEmployeeModel(connections.hrms);
    const { Department } = getDepartmentModel(connections.hrms); // Assuming this exists
 
    // First find the IT department's _id
    const itDept = await Department.findOne({ name: 'Information Technology' });
 
    if (!itDept) {
      return res.status(404).json({ message: 'Information Technology  department not found' });
    }
 
    const employees = await Employee.find({ department: itDept._id });
 
    res.status(200).json(employees);
  } catch (error) {
    console.error("Failed to fetch Information Technology department employees:", error);
    res.status(500).json({ message: "Error fetching employees", error });
  }
};
 
 
exports.fetchAllUsers = async (req, res) => {
  try{
    const { User } = fetchAllUser(connections.hrms);
      const users = await User.find({isDeleted: false});
      if(!users || users.length === 0){
          return res.status(400).json({message:"USER NOT FOUND"});
      }
      // Map through the users array and extract the relevant fields
      const userDetails = users.map(user => ({
          fullName: user.fullName,
          email: user.email,
          username: user.username,
          contact: user.contact,
          role: user.role,
          id: user.userId,
          profilePicture: user.profilePicture,
          filetype: user.profileImageType,
          isDeleted: user.isDeleted,
          rolePriority: user.rolePriority
      }));
 
     // userDetails.sort((a, b) => a.rolePriority - b.rolePriority);
     
      return res.status(200).json(userDetails);
  }catch(error) {
      console.log(error);
      return res.status(500).json({message:"Server Error", error});
  }
};
 



 
 
 
 
// exports.sendOtpForLogin = async (req, res) => {
//   try {
//     const { email, password } = req.body;
//     const { User } = sendOtpForLogin(connections.hrms); // HRMS DB (read-only)
//     const OtpVerification = getOtpVerificationModel(connections.main); // Main DB (writable)

//     if (!validateEmailFormat(email)) {
//       return res.status(400).json({ message: "Invalid email format" });
//     }

//     const user = await User.findOne({ email, isDeleted: false });
//     if (!user) {
//       return res.status(404).json({ message: "Email does not exist" });
//     }

//     let otpRecord = await OtpVerification.findOne({ email });

//     if (otpRecord && otpRecord.freezeUntil && otpRecord.freezeUntil > Date.now()) {
//       return res.status(400).json({
//         message: "Your account is currently frozen. Please try again later.",
//       });
//     }

//     const isPasswordMatch = await user.comparePassword(password);
//     if (!isPasswordMatch) {
//       if (!otpRecord) {
//         otpRecord = await OtpVerification.create({ email, failedAttempts: 0 });
//       }
//       otpRecord.failedAttempts += 1;
//       if (otpRecord.failedAttempts >= 3) {
//         otpRecord.freezeUntil = Date.now() + 15 * 60 * 1000;
//       }
//       await otpRecord.save();
//       return res.status(401).json({
//         message: "Invalid credentials: either email or password",
//       });
//     }

//     // Generate OTP
//     const otp = crypto.randomInt(100000, 999999).toString();
//     console.log("Generated OTP:", otp, "for email:", email);

//     const hashedLoginOtp = await bcrypt.hash(otp, 10);
//     const tokenExpireTime = Date.now() + 10 * 60 * 1000;

//     if (otpRecord) {
//       otpRecord.loginOTP = hashedLoginOtp;
//       otpRecord.tokenExpireTime = tokenExpireTime;
//       otpRecord.failedAttempts = 0;
//       otpRecord.freezeUntil = null;
//       await otpRecord.save();
//     } else {
//       await OtpVerification.create({
//         email,
//         loginOTP: hashedLoginOtp,
//         tokenExpireTime,
//         failedAttempts: 0,
//         freezeUntil: null,
//       });
//     }

//     const emailContentForLogin = `
//       <html>
//         <body style="font-family: Arial, sans-serif; color: #333;">
//           <p>We received a request for Login. To complete the login, please use the following One-Time-Password (OTP):</p>
//           <p style="font-size: 20px; text-align:center; font-weight: bold; color:rgb(68, 152, 231);">${otp}</p>
//           <p>This OTP is valid for the next 10 minutes.</p>
//           <p>Thank you for using our service!</p>
//           <p>Best Regards,<br>AAS International</p>
//         </body>
//       </html>
//     `;

//     await sendEmail("Login OTP", emailContentForLogin, email);

//     // ✅ Ensure response includes OTP (for testing only)
//     return res.status(200).json({
//       success: true,
//       message: "OTP sent successfully",
//       otp: otp, // make sure you explicitly send it
//     });

//   } catch (error) {
//     console.error("Send OTP Error:", error);
//     return res.status(500).json({ success: false, message: "Invalid Credentials", error: error.message });
//   }
// };



exports.sendOtpForLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    const { User } = sendOtpForLogin(connections.hrms); // HRMS DB (read-only)
    const OtpVerification = getOtpVerificationModel(connections.main); // Main DB (writable)
 
    // Validate email format
    if (!validateEmailFormat(email)) {
      return res.status(400).json({ message: "Invalid email format" });
    }
 
    // Find user in HRMS DB
    const user = await User.findOne({ email, isDeleted: false });
    if (!user) {
      return res.status(404).json({ message: "Email does not exist" });
    }
 
    // Check existing OTP record in Main DB
    let otpRecord = await OtpVerification.findOne({ email });
 
    // Check if account is frozen
    if (otpRecord && otpRecord.freezeUntil && otpRecord.freezeUntil > Date.now()) {
      return res.status(400).json({
        message: "Your account is currently frozen. Please try again later.",
      });
    }
 
    // Check password
    const isPasswordMatch = await user.comparePassword(password);
    if (!isPasswordMatch) {
      if (!otpRecord) {
        otpRecord = await OtpVerification.create({ email, failedAttempts: 0 });
      }
      otpRecord.failedAttempts += 1;
      if (otpRecord.failedAttempts >= 3) {
        otpRecord.freezeUntil = Date.now() + 15 * 60 * 1000; // 15 mins
      }
      await otpRecord.save();
      return res.status(401).json({
        message: "Invalid credentials: either email or password",
      });
    }
 
    // Generate OTP
    const otp = crypto.randomInt(100000, 999999).toString();
    const hashedLoginOtp = await bcrypt.hash(otp, 10);
    const tokenExpireTime = Date.now() + 10 * 60 * 1000;//token expried at 10 minutes from now
 
    // Update or create OTP record
    if (otpRecord) {
      otpRecord.loginOTP = hashedLoginOtp;
      otpRecord.tokenExpireTime = tokenExpireTime;
      otpRecord.failedAttempts = 0;
      otpRecord.freezeUntil = null;
      await otpRecord.save();
    } else {
      await OtpVerification.create({
        email,
        loginOTP: hashedLoginOtp,
        tokenExpireTime,
        failedAttempts: 0,
        freezeUntil: null,
      });
    }
 
    // HTML Email Template
    const emailContentForLogin = `
      <html>
        <body style="font-family: Arial, sans-serif; color: #333;">
          <p>We received a request for Login. To complete the login, please use the following One-Time-Password (OTP):</p>
          <p style="font-size: 20px; text-align:center; font-weight: bold; color:rgb(68, 152, 231);">${otp}</p>
          <p>This OTP is valid for the next 10 minutes. Please do not share this OTP with anyone for security reasons.</p>
          <p>If you did not request this, please ignore this email.</p>
          <p>Thank you for using our service!</p>
          <p>Best Regards,<br>AAS International</p>
        </body>
      </html>
    `;
 
    // Email sending
    // const mailingOptions = {
    //   from: process.env.EMAIL_ID,
    //   to: user.email,
    //   subject: "Your HRMS Login OTP: Secure Access Code Inside",
    //   html: emailContentForLogin,
    // };
 
    await sendEmail('Login OTP',emailContentForLogin,email);
 
    return res.status(200).json({
      message: "OTP sent successfully",
      // user: {
      //   email: user.email,
      //   username: user.username,
      //   fullName: user.fullName,
      //   role: user.role,
      //   userId: user.userId,
      // },
    });
  } catch (error) {
    console.error("Send OTP Error:", error);
    return res.status(500).json({ message: "Invalid Credenetials", error });
  }
};
 

function validateEmailFormat(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
 
 

 const generateRefreshToken = (payload) => {
  return jwt.sign(payload, process.env.JWT_REFRESH_SECRET_KEY, { expiresIn: "7d" }); // refresh valid for 7 days
};

 
 
const generateToken = (payload) => {
    return jwt.sign(payload, process.env.JWT_SECRET_KEY, { expiresIn: "15m" });
};
 

 
 
 
exports.verifyLoginOTP = async (req, res) => {
  try {
    const { email, otp } = req.body;
    const { User, Employee } = verifyLoginOTP(connections.hrms);
    const Session = require('../../Model/HrmsModel/sessionModel')(connections.main);
    const OtpVerification = getOtpVerificationModel(connections.main);
 
    // Initialize session service
    const { verifyOTPAndCreateSession } = sessionService(User, Session, OtpVerification);
 
    // Device/IP
    const deviceInfo = req.headers['user-agent'] || 'Unknown';
    const ipAddress = req.ip || 'Unknown';
 
    // Verify OTP and create session
    const { session, user } = await verifyOTPAndCreateSession(email, otp, deviceInfo, ipAddress);
 
    // Create Access + Refresh tokens
    const accessToken = generateToken({ id: user._id, role: user.role });
    const refreshToken = generateRefreshToken({ id: user._id, role: user.role });
 
    // Save refresh token in DB (optional but recommended for security/revocation)
    session.refreshToken = refreshToken;
    await session.save();
 
    // Set cookies
    res.cookie('token', accessToken, {
      httpOnly: false,
      secure: false,
      maxAge: 24 * 60 * 60 * 1000, // 1 day
      sameSite: 'lax',
      path: '/',
    });
 
    res.cookie('refreshToken', refreshToken, {
      httpOnly: false,
      secure: false,
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      sameSite: 'lax',
      path: '/',
    });
    res.cookie('email', email, {
      httpOnly: false,
      secure: false,
      maxAge: 24 * 60 * 60 * 1000, // 1days
      sameSite: 'lax',
      path: '/',
    });
 
    return res.status(200).json({
      message: 'Login successful',
      accessToken,
      refreshToken,
    });
  } catch (error) {
    console.error('OTP Verification Error:', error.message);
    return res.status(400).json({ message: error.message });
  }
};
 
 
 



 


 
exports.getUserByEmail = async (req, res) => {
  try {
    const { email } = req.params; // Expect email in request body
    const { User, Employee } = verifyLoginOTP(connections.hrms);
 
    // Find user in HRMS DB
    const user = await User.findOne({ email }).select('-password'); // Exclude password
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
 
    const employee = await Employee.findOne({ email });
    const employeeData = employee ? employee.toObject() : null;
 
 
 
    // Return only the message for consistency
    return res.status(200).json({ message: "User data retrieved successfully", user , employeeData});
  } catch (error) {
    console.error("User Fetch Error:", error);
    return res.status(500).json({ message: "Error fetching user data" });
  }
};
 
 

 
// exports.logout = async (req, res) => {
//   try {
//     const cookieOptions = {
//       httpOnly: true,
//       secure: true, // set to true if using HTTPS in production
//       sameSite: 'None',
//       path: '/',
//     };
 
//     res.clearCookie('token', cookieOptions);
//     res.clearCookie('email', cookieOptions);
 
//     return res.status(200).json({ message: "Logout successful" });
//   } catch (error) {
//     console.error("Logout Error:", error);
//     return res.status(500).json({ message: "Error logging out", error: error.message });
//   }
// };
 exports.logout = async (req, res) => {
  try {
    const cookieOptions = {
      httpOnly: true,
      secure: true, // set to true if using HTTPS in production
      sameSite: 'None',
      path: '/',
    };
 
    res.clearCookie('token', cookieOptions);
    res.clearCookie('email', cookieOptions);
    res.clearCookie('refreshToken', cookieOptions);
 
    return res.status(200).json({ message: "Logout successful" });
  } catch (error) {
    console.error("Logout Error:", error);
    return res.status(500).json({ message: "Error logging out", error: error.message });
  }
};
 
exports.logoutAllDevices = async (req, res) => {
  try {
    const email = req.cookies.email || req.body.email;
    if (!email) {
      return res.status(400).json({ message: 'Email required for logout' });
    }
 
    const Session = require('../../Model/HrmsModel/sessionModel')(connections.main);
    const { deleteAllSessions } = sessionService(null, Session, null);
 
    await deleteAllSessions(email);
 
    res.clearCookie('sessionToken', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'None',
    });
    res.clearCookie('email', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'None',
    });
 
    return res.status(200).json({ message: 'Successfully logged out from all devices' });
  } catch (error) {
    console.error('Logout All Devices Error:', error);
    return res.status(500).json({ message: 'Error logging out from all devices', error: error.message });
  }
};
 
// controllers/userController.js
exports.getUserByEmailFromCookie = async (req, res) => {
  try {
    const email = req.cookies.email; // Fetch email from cookies
    if (!email) {
      return res.status(400).json({ message: "Email cookie is missing" });
    }
 
    const { User, Employee } = verifyLoginOTP(connections.hrms);
 
    const user = await User.findOne({ email }).select('-password');
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
 
    const employee = await Employee.findOne({ email });
    const employeeData = employee ? employee.toObject() : null;
 
    return res.status(200).json({
      message: "User and employee data retrieved successfully",
      user,
      employee: employeeData,
    });
  } catch (error) {
    console.error("Fetch User by Cookie Error:", error);
    return res.status(500).json({ message: "Error fetching user data", error: error.message });
  }
};
 
 
 
exports.checkToken = async (req, res) => {
    try{
       
        const token  = req.cookies.token;
       
       
        const isPresent = !!token;
 
        if(!isPresent){
            return res.status(200).json({message: "Token is not present", dashboard: false});
        }
        return res.status(200).json({message: "Token is present", dashboard: true});
 
    }catch(error){
        console.log(error);
        return res.status(500).json({message: "Internal Server error, please try again later", error: error.message});
    }
}



// exports.uploadProfileImage = async (req, res) => {
//   try {
//     const { Employee } = getEmployeeModel(connections.hrms);
//     const { employeeID } = req.params; // e.g., "AAS-IT-A-001-24"
 
//     //  Find Employee by employeeID field, not _id
//     const user = await Employee.findOne({ employeeID: employeeID });
//     if (!user) {
//       return res.status(404).json({ message: "Employee not found" });
//     }
 
//     if (!req.file) {
//       return res.status(400).json({ message: "No image uploaded" });
//     }
 
//     // Ensure folder exists
//     const uploadDir = path.join(process.cwd(), "uploads", "profiles");
//     if (!fs.existsSync(uploadDir)) {
//       fs.mkdirSync(uploadDir, { recursive: true });
//     }
 
//     // Save profile
//     const profile = new Profile({
//       employeeID, // string field from Employee
//       imagePath: req.file.path,
//     });
 
//     await profile.save();
 
//     res.status(201).json({
//       message: "Profile image uploaded successfully",
//       profile,
//     });
//   } catch (error) {
//     console.error("Error uploading profile image:", error);
//     res.status(500).json({
//       message: "Error uploading profile image",
//       error: error.message,
//     });
//   }
// };
 


exports.uploadProfileImage = async (req, res) => {
  try {
    const { Employee } = getEmployeeModel(connections.hrms);
    const { employeeID } = req.params; // e.g., "AAS-IT-A-001-24"
 
    // Find Employee by employeeID field, not _id
    const user = await Employee.findOne({ employeeID });
    if (!user) {
      return res.status(404).json({ message: "Employee not found" });
    }
 
    if (!req.file) {
      return res.status(400).json({ message: "No image uploaded" });
    }
 
    // Ensure folder exists
    const uploadDir = path.join(process.cwd(), "uploads", "profiles");
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
 
    // Check if profile already exists
    let profile = await Profile.findOne({ employeeID });
 
    if (profile) {
      // If profile exists, delete old image from disk
      if (fs.existsSync(profile.imagePath)) {
        fs.unlinkSync(profile.imagePath);
      }
 
      // Update with new image path
      profile.imagePath = req.file.path;
      profile.updatedAt = new Date();
      await profile.save();
 
      return res.status(200).json({
        message: "Profile image updated successfully",
        profile,
      });
    } else {
      // Create new profile if none exists
      profile = new Profile({
        employeeID,
        imagePath: req.file.path,
      });
 
      await profile.save();
 
      return res.status(201).json({
        message: "Profile image uploaded successfully",
        profile,
      });
    }
  } catch (error) {
    console.error("Error uploading/updating profile image:", error);
    res.status(500).json({
      message: "Error uploading/updating profile image",
      error: error.message,
    });
  }
};

 
exports.viewProfileImage = async (req, res) => {
  try {
    const { employeeId } = req.params;
 
    // 1. Find the profile in DB
    const profileRecord = await Profile.findOne({ employeeID: employeeId, isDeleted: false });
    if (!profileRecord) {
      return res.status(404).json({ message: "Profile not found." });
    }
 
    // 2. Build absolute file path
    const filePath = path.resolve(process.cwd(), profileRecord.imagePath);
    console.log("Serving image from:", filePath);
 
    // 3. Check if file exists
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "File not found on server." });
    }
 
    // 4. Detect content type
    const contentType = mime.lookup(filePath) || "application/octet-stream";
 
    res.setHeader("Content-Type", contentType);
    res.setHeader(
      "Content-Disposition",
      `inline; filename="${path.basename(filePath)}"`
    );
 
    // 5. Stream the image/file
    fs.createReadStream(filePath).pipe(res);
  } catch (error) {
    console.error("Error viewing profile image:", error);
    res
      .status(500)
      .json({ message: "Failed to view profile image", error: error.message });
  }
};





exports.getAllHRMSEmployeesExceptITAndBiotech = async (req, res) => {
  try {
    const { Employee } = getEmployeeModel(connections.hrms);
    const { Department } = getDepartmentModel(connections.hrms);
 
    // Find the IT and Biotechnology department _ids
    const excludedDepartments = await Department.find({
      name: { $in: ['Information Technology', 'Biotechnology','Biosciences'] },
    });
 
    const excludedDeptIds = excludedDepartments.map((dept) => dept._id);
 
    // Fetch employees NOT in the excluded departments
    const employees = await Employee.find({
      department: { $nin: excludedDeptIds },
    });
 
    res.status(200).json(employees);
  } catch (error) {
    console.error("Failed to fetch employees excluding Information Technology & Biotechnology:", error);
    res.status(500).json({
      message: "Error fetching employees",
      error,
    });
  }
};
